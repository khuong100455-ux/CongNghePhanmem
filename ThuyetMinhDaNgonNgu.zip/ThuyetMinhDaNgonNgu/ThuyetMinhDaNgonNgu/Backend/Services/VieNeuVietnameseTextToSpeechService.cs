using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace ThuyetMinhDaNgonNgu.Backend.Services;

public sealed class VieNeuVietnameseTextToSpeechService(
    IHttpClientFactory httpClientFactory,
    IConfiguration configuration,
    IMemoryCache cache,
    ILogger<VieNeuVietnameseTextToSpeechService> logger,
    IHostEnvironment hostEnvironment) : IAsyncDisposable
{
    private const string PythonName = "VIENEU_PYTHON";
    private readonly SemaphoreSlim _startLock = new(1, 1);
    private Process? _serverProcess;
    private Uri? _serverAddress;
    private string? _serverError;

    public bool HasVoiceReference => File.Exists(GetReferenceAudioPath());

    public async Task<string> SynthesizeVietnameseAsync(
        string text,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            throw new VieNeuTextToSpeechException("Nội dung thuyết minh đang trống.");
        }

        var referenceAudioPath = GetReferenceAudioPath();
        if (!File.Exists(referenceAudioPath))
        {
            throw new VieNeuTextToSpeechException(
                $"Chưa tìm thấy file giọng mẫu. Hãy chạy Setup-VieNeu.ps1 và chọn file âm thanh. Đường dẫn mong đợi: {referenceAudioPath}");
        }

        var referenceFile = new FileInfo(referenceAudioPath);
        var cacheKey = $"vieneu:{referenceFile.Length}:{referenceFile.LastWriteTimeUtc.Ticks}:{Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)))}";
        if (cache.TryGetValue(cacheKey, out string? cachedAudio) &&
            !string.IsNullOrWhiteSpace(cachedAudio))
        {
            return cachedAudio;
        }

        var serverAddress = await EnsureServerStartedAsync(referenceAudioPath, cancellationToken);
        try
        {
            var requestBody = JsonSerializer.SerializeToUtf8Bytes(new { text });
            using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(serverAddress, "synthesize"))
            {
                Content = new ByteArrayContent(requestBody)
            };
            request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            using var response = await httpClientFactory.CreateClient(nameof(VieNeuVietnameseTextToSpeechService))
                .SendAsync(request, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await response.Content.ReadAsStringAsync(cancellationToken);
                throw new VieNeuTextToSpeechException(
                    $"VieNeu không tạo được giọng đọc (HTTP {(int)response.StatusCode}): {errorBody}");
            }

            var audio = await response.Content.ReadAsByteArrayAsync(cancellationToken);
            if (audio.Length < 44 ||
                !audio.AsSpan(0, 4).SequenceEqual("RIFF"u8) ||
                !audio.AsSpan(8, 4).SequenceEqual("WAVE"u8))
            {
                throw new VieNeuTextToSpeechException("VieNeu đã trả về tệp WAV không hợp lệ.");
            }

            var encodedAudio = Convert.ToBase64String(audio);
            cache.Set(cacheKey, encodedAudio, TimeSpan.FromHours(12));
            return encodedAudio;
        }
        catch (HttpRequestException exception)
        {
            throw new VieNeuTextToSpeechException(
                "Mất kết nối với VieNeu cục bộ. Hãy khởi động lại ứng dụng rồi thử lại.",
                exception);
        }
        catch (OperationCanceledException exception) when (!cancellationToken.IsCancellationRequested)
        {
            throw new VieNeuTextToSpeechException(
                "VieNeu tạo giọng đọc quá lâu. Hãy thử lại.",
                exception);
        }
    }

    private string GetReferenceAudioPath()
    {
        var configuredPath = configuration["VIENEU_REFERENCE_AUDIO"];
        return string.IsNullOrWhiteSpace(configuredPath)
            ? Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DauChanViet",
                "VieNeu",
                "voice-reference.wav")
            : Path.GetFullPath(configuredPath);
    }

    private string GetServerScriptPath()
    {
        var outputPath = Path.Combine(AppContext.BaseDirectory, "Backend", "Services", "vieneu_local_server.py");
        if (File.Exists(outputPath))
        {
            return outputPath;
        }

        var contentPath = Path.Combine(hostEnvironment.ContentRootPath, "Backend", "Services", "vieneu_local_server.py");
        if (File.Exists(contentPath))
        {
            return contentPath;
        }

        throw new VieNeuTextToSpeechException(
            "Không tìm thấy tiến trình máy chủ TTS cục bộ. Hãy cài đặt lại ứng dụng.");
    }

    private async Task<Uri> EnsureServerStartedAsync(
        string referenceAudioPath,
        CancellationToken cancellationToken)
    {
        if (_serverProcess is { HasExited: false } && _serverAddress is not null)
        {
            return _serverAddress;
        }

        await _startLock.WaitAsync(cancellationToken);
        try
        {
            if (_serverProcess is { HasExited: false } && _serverAddress is not null)
            {
                return _serverAddress;
            }

            var pythonPath = configuration[PythonName];
            if (string.IsNullOrWhiteSpace(pythonPath))
            {
                var installedPython = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Programs",
                    "Python",
                    "Python312",
                    "python.exe");
                pythonPath = File.Exists(installedPython) ? installedPython : "python";
            }

            var cacheDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DauChanViet",
                "VieNeu",
                "model-cache");
            Directory.CreateDirectory(cacheDirectory);

            var port = GetAvailablePort();
            var startInfo = new ProcessStartInfo
            {
                FileName = pythonPath,
                WorkingDirectory = cacheDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true
            };
            startInfo.ArgumentList.Add("-u");
            startInfo.ArgumentList.Add(GetServerScriptPath());
            startInfo.ArgumentList.Add("--host");
            startInfo.ArgumentList.Add("127.0.0.1");
            startInfo.ArgumentList.Add("--port");
            startInfo.ArgumentList.Add(port.ToString());
            startInfo.ArgumentList.Add("--reference-audio");
            startInfo.ArgumentList.Add(referenceAudioPath);
            startInfo.Environment["HF_HOME"] = cacheDirectory;
            startInfo.Environment["HF_HUB_DISABLE_TELEMETRY"] = "1";
            startInfo.Environment["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1";

            try
            {
                _serverProcess = Process.Start(startInfo);
            }
            catch (Exception exception) when (
                exception is System.ComponentModel.Win32Exception or FileNotFoundException)
            {
                throw new VieNeuTextToSpeechException(
                    "Không tìm thấy Python hoặc VieNeu. Hãy chạy Setup-VieNeu.ps1 rồi khởi động lại ứng dụng.",
                    exception);
            }

            if (_serverProcess is null)
            {
                throw new VieNeuTextToSpeechException("Không thể khởi động VieNeu cục bộ.");
            }

            _serverError = null;
            _serverProcess.ErrorDataReceived += (_, eventArgs) =>
            {
                if (!string.IsNullOrWhiteSpace(eventArgs.Data))
                {
                    _serverError = eventArgs.Data;
                    logger.LogInformation("VieNeu: {Message}", eventArgs.Data);
                }
            };
            _serverProcess.BeginErrorReadLine();
            _serverAddress = new Uri($"http://127.0.0.1:{port}/");

            try
            {
                using var readinessClient = new HttpClient { Timeout = TimeSpan.FromSeconds(2) };
                var readinessDeadline = DateTime.UtcNow.AddMinutes(10);
                while (DateTime.UtcNow < readinessDeadline)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (_serverProcess.HasExited)
                    {
                        var diagnostic = string.IsNullOrWhiteSpace(_serverError)
                            ? "Hãy kiểm tra gói vieneu và model tiếng Việt."
                            : $"Chi tiết: {_serverError}";
                        throw new VieNeuTextToSpeechException(
                            $"Tiến trình VieNeu đã dừng khi khởi động (mã lỗi {_serverProcess.ExitCode}). {diagnostic}");
                    }

                    try
                    {
                        using var response = await readinessClient.GetAsync(
                            new Uri(_serverAddress, "health"),
                            cancellationToken);
                        if (response.IsSuccessStatusCode)
                        {
                            logger.LogInformation("VieNeu Vietnamese voice-cloning server started on loopback port {Port}.", port);
                            return _serverAddress;
                        }
                    }
                    catch (HttpRequestException)
                    {
                    }
                    catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
                    {
                    }

                    await Task.Delay(500, cancellationToken);
                }

                var timeoutDiagnostic = string.IsNullOrWhiteSpace(_serverError)
                    ? string.Empty
                    : $" Chi tiết: {_serverError}";
                throw new VieNeuTextToSpeechException(
                    $"VieNeu chưa sẵn sàng sau 10 phút. Hãy kiểm tra kết nối tải model rồi thử lại.{timeoutDiagnostic}");
            }
            catch
            {
                await StopServerAsync();
                throw;
            }
        }
        finally
        {
            _startLock.Release();
        }
    }

    private static int GetAvailablePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }

    private async Task StopServerAsync()
    {
        if (_serverProcess is null)
        {
            return;
        }

        try
        {
            if (!_serverProcess.HasExited)
            {
                _serverProcess.Kill(entireProcessTree: true);
                await _serverProcess.WaitForExitAsync();
            }
        }
        catch (InvalidOperationException)
        {
        }
        finally
        {
            _serverProcess.Dispose();
            _serverProcess = null;
            _serverAddress = null;
        }
    }

    public async ValueTask DisposeAsync()
    {
        await _startLock.WaitAsync();
        try
        {
            await StopServerAsync();
        }
        finally
        {
            _startLock.Release();
            _startLock.Dispose();
        }
    }
}

public sealed class VieNeuTextToSpeechException(string message, Exception? innerException = null)
    : Exception(message, innerException);
