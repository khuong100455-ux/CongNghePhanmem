using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace ThuyetMinhDaNgonNgu.Backend.Services;

public sealed class GeminiNarrationService(
    HttpClient httpClient,
    IConfiguration configuration,
    IMemoryCache cache)
{
    private static readonly Uri InteractionsEndpoint = new("https://generativelanguage.googleapis.com/v1beta/interactions");
    private static readonly IReadOnlyDictionary<string, string> SupportedLanguages = new Dictionary<string, string>
    {
        ["vi"] = "Vietnamese",
        ["en"] = "English",
        ["zh"] = "Simplified Chinese",
        ["ja"] = "Japanese",
        ["ko"] = "Korean"
    };

    private readonly string _apiKey =
        configuration["GEMINI_API_KEY"] ?? configuration["Gemini:ApiKey"] ?? string.Empty;

    private readonly string _model =
        configuration["GEMINI_MODEL"] ?? configuration["Gemini:Model"] ?? "gemini-3.1-flash-lite";

    public async Task<string> GenerateAsync(
        string destinationId,
        string name,
        string region,
        string highlights,
        string sourceDescription,
        string languageCode,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_apiKey))
        {
            throw new GeminiNarrationException(
                "Chưa cấu hình Gemini API key. Hãy đặt biến môi trường GEMINI_API_KEY rồi khởi động lại ứng dụng.");
        }

        if (!SupportedLanguages.TryGetValue(languageCode, out var languageName))
        {
            throw new GeminiNarrationException("Ngôn ngữ thuyết minh hiện chưa được hỗ trợ.");
        }

        var cacheKey = $"gemini-narration:v2:{_model}:{destinationId}:{languageCode}";
        if (cache.TryGetValue(cacheKey, out string? cachedNarration) &&
            !string.IsNullOrWhiteSpace(cachedNarration))
        {
            return cachedNarration;
        }

        var speechGuidance = languageCode == "vi"
            ? """
                For Vietnamese, write natural spoken Vietnamese with correct Vietnamese tone marks.
                Avoid English words, English abbreviations, and English phrases. Prefer clear Vietnamese
                alternatives for foreign or technical terms. Keep Vietnamese place names in Vietnamese;
                do not add English translations or pronunciation hints.
                """
            : $"""
                Use natural spoken {languageName} suitable for text-to-speech. Avoid mixing in Vietnamese
                or unrelated languages. Preserve a destination's Vietnamese proper name only when needed.
                """;

        var requestBody = new
        {
            model = _model,
            store = false,
            system_instruction = $"""
                You are a careful multilingual audio tour guide for destinations in Vietnam.
                Write the entire narration in {languageName}, with no sentences or phrases in any other language.
                Preserve destination names as proper nouns, but translate all other information into {languageName}.
                {speechGuidance}
                Keep it between 50 and 80 words. Use only the destination facts provided in the user input.
                Do not invent dates, legends, opening hours, ticket prices, safety conditions, directions, transport,
                or other unsupported facts. If the provided facts are brief, describe them naturally and avoid
                adding new factual claims. Return narration text only, with no title, bullet points, markdown,
                citations, language labels, or stage directions.
                """,
            input = $"""
                Create an audio-guide narration for this destination.
                Name: {name}
                Region: {region}
                Destination highlights (translate these into {languageName}): {highlights}
                Destination description (translate this into {languageName}): {sourceDescription}
                Speak directly to an interested visitor, in {languageName} only, and make it pleasant to listen to.
                """,
            generation_config = new { thinking_level = "low", max_output_tokens = 240 }
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, InteractionsEndpoint)
        {
            Content = JsonContent.Create(requestBody)
        };
        request.Headers.TryAddWithoutValidation("x-goog-api-key", _apiKey);

        HttpResponseMessage response;
        try
        {
            response = await httpClient.SendAsync(request, cancellationToken);
        }
        catch (HttpRequestException exception)
        {
            throw new GeminiNarrationException(
                "Không kết nối được Gemini. Hãy kiểm tra kết nối Internet rồi thử lại.",
                exception);
        }
        catch (OperationCanceledException exception) when (!cancellationToken.IsCancellationRequested)
        {
            throw new GeminiNarrationException(
                "Gemini phản hồi quá lâu. Hãy thử tạo lời thuyết minh lại.",
                exception);
        }
        using (response)
        {
            if (!response.IsSuccessStatusCode)
            {
                throw new GeminiNarrationException(GetProviderError(response.StatusCode));
            }

            var responseJson = await response.Content.ReadAsStringAsync(cancellationToken);
            string narration;
            try
            {
                narration = ExtractNarration(responseJson);
            }
            catch (JsonException exception)
            {
                throw new GeminiNarrationException("Gemini trả về nội dung không đọc được. Hãy thử lại.", exception);
            }
            cache.Set(cacheKey, narration, TimeSpan.FromHours(12));
            return narration;
        }
    }

    private static string ExtractNarration(string responseJson)
    {
        using var document = JsonDocument.Parse(responseJson);
        if (!document.RootElement.TryGetProperty("output", out var output) ||
            output.ValueKind != JsonValueKind.Array)
        {
            throw new GeminiNarrationException("Gemini trả về phản hồi không đúng định dạng.");
        }

        var narration = string.Join(
            Environment.NewLine,
            output.EnumerateArray()
                .Where(item =>
                    item.TryGetProperty("type", out var type) &&
                    type.ValueKind == JsonValueKind.String &&
                    type.GetString() == "text")
                .Select(item =>
                    item.TryGetProperty("text", out var text) &&
                    text.ValueKind == JsonValueKind.String
                        ? text.GetString()
                        : null)
                .Where(text => !string.IsNullOrWhiteSpace(text)))
            .Trim();

        if (string.IsNullOrWhiteSpace(narration))
        {
            throw new GeminiNarrationException("Gemini chưa tạo được nội dung thuyết minh. Hãy thử lại.");
        }

        return narration;
    }

    private static string GetProviderError(HttpStatusCode statusCode) => statusCode switch
    {
        HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden =>
            "Gemini từ chối API key. Hãy kiểm tra lại biến môi trường GEMINI_API_KEY.",
        HttpStatusCode.TooManyRequests =>
            "Gemini đang giới hạn số yêu cầu. Hãy chờ một chút rồi thử lại.",
        HttpStatusCode.NotFound =>
            "Không tìm thấy Gemini model hoặc API endpoint. Hãy kiểm tra GEMINI_MODEL.",
        HttpStatusCode.BadRequest =>
            "Gemini từ chối nội dung hoặc cấu hình yêu cầu. Hãy thử lại; nếu tiếp tục, kiểm tra model và API key.",
        _ when (int)statusCode >= 500 =>
            "Dịch vụ Gemini hiện đang gặp sự cố. Hãy thử lại sau.",
        _ => $"Không thể tạo lời thuyết minh bằng Gemini (HTTP {(int)statusCode})."
    };
}

public sealed class GeminiNarrationException(string message, Exception? innerException = null)
    : Exception(message, innerException);
