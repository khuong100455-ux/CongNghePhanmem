import argparse
import io
import json
import logging
from http.server import BaseHTTPRequestHandler, HTTPServer

import soundfile as sf
from vieneu import Vieneu


MAX_REQUEST_BYTES = 1_000_000
MAX_TEXT_LENGTH = 20_000


class SynthesisHandler(BaseHTTPRequestHandler):
    tts = None
    reference_audio = None

    def do_GET(self):
        if self.path != "/health":
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        if self.path != "/synthesize":
            self.send_error(404)
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length <= 0 or content_length > MAX_REQUEST_BYTES:
                self._send_json(413, {"error": "Request size is invalid."})
                return

            payload = json.loads(self.rfile.read(content_length))
            text = payload.get("text") if isinstance(payload, dict) else None
            if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT_LENGTH:
                self._send_json(400, {"error": "Text is empty or too long."})
                return

            audio = self.tts.infer(
                text.strip(),
                ref_audio=self.reference_audio,
                denoise=True,
            )
            audio_buffer = io.BytesIO()
            sf.write(audio_buffer, audio, self.tts.sample_rate, format="WAV", subtype="PCM_16")
            audio_bytes = audio_buffer.getvalue()

            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(audio_bytes)))
            self.end_headers()
            self.wfile.write(audio_bytes)
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._send_json(400, {"error": "Request must contain valid JSON."})
        except Exception as exception:
            logging.exception("VieNeu speech synthesis failed")
            self._send_json(500, {"error": str(exception)[:500]})

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format_string, *args):
        logging.info(format_string, *args)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--reference-audio", required=True)
    args = parser.parse_args()

    SynthesisHandler.reference_audio = args.reference_audio
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.info("Loading VieNeu on CPU and preparing the local voice reference.")
    SynthesisHandler.tts = Vieneu(device="cpu", backend="onnx")

    server = HTTPServer((args.host, args.port), SynthesisHandler)
    logging.info("VieNeu voice-cloning server ready at http://%s:%s", args.host, args.port)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
