import os
import sys

import numpy as np
import soundfile as sf


def main():
    if len(sys.argv) != 3:
        raise SystemExit("Usage: prepare_vieneu_reference.py <source-audio> <output-wav>")

    source_path, output_path = sys.argv[1:]
    info = sf.info(source_path)
    if info.duration < 3:
        raise ValueError("Voice sample must be at least 3 seconds long.")

    audio, sample_rate = sf.read(source_path, dtype="float32", always_2d=False)
    if audio.ndim > 1:
        audio = audio.mean(axis=1)

    audio = np.asarray(audio[: sample_rate * 8], dtype=np.float32)
    if audio.size < sample_rate * 3 or not np.isfinite(audio).all():
        raise ValueError("Voice sample does not contain at least 3 seconds of clear audio.")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    sf.write(output_path, audio, sample_rate, subtype="PCM_16")
    print(f"Prepared {audio.size / sample_rate:.1f} seconds of mono voice reference.")


if __name__ == "__main__":
    main()
