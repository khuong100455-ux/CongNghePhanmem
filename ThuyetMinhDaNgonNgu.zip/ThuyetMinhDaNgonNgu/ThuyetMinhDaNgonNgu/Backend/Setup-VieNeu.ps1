param(
    [string]$ReferenceAudioPath
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

if ([string]::IsNullOrWhiteSpace($ReferenceAudioPath)) {
    $ReferenceAudioPath = Read-Host "Enter the full path to your authorized voice sample (WAV, MP3, or FLAC)"
}

if (-not (Test-Path -LiteralPath $ReferenceAudioPath -PathType Leaf)) {
    throw "Voice sample not found: $ReferenceAudioPath"
}

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
$pythonPath = if ($pythonCommand) { $pythonCommand.Source } else { $null }
if (-not $pythonPath -or $pythonPath -like "*\WindowsApps\python.exe") {
    $pythonPath = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
}

if (-not (Test-Path -LiteralPath $pythonPath)) {
    Write-Host "Installing Python 3.12 for the current Windows user..."
    winget install --id Python.Python.3.12 --source winget --scope user --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "Python installation failed. Install Python 3.12 from python.org, then run this script again."
    }
}

if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw "Python was installed but could not be found at $pythonPath."
}

$voiceDirectory = Join-Path $env:LOCALAPPDATA "DauChanViet\VieNeu"
$referenceAudio = Join-Path $voiceDirectory "voice-reference.wav"
$modelCache = Join-Path $voiceDirectory "model-cache"
$prepareScript = Join-Path $PSScriptRoot "Services\prepare_vieneu_reference.py"
New-Item -ItemType Directory -Force -Path $voiceDirectory, $modelCache | Out-Null

Write-Host "Installing VieNeu Vietnamese TTS..."
& $pythonPath -m pip install --upgrade vieneu
if ($LASTEXITCODE -ne 0) {
    throw "Could not install vieneu. Check the Python/pip installation and try again."
}

Write-Host "Preparing the first 8 seconds of the voice sample locally..."
& $pythonPath $prepareScript $ReferenceAudioPath $referenceAudio
if ($LASTEXITCODE -ne 0) {
    throw "The voice sample could not be decoded. Use a clear WAV, MP3, or FLAC file at least 3 seconds long."
}

$env:HF_HOME = $modelCache
$env:HF_HUB_DISABLE_TELEMETRY = "1"
$env:HF_HUB_DISABLE_IMPLICIT_TOKEN = "1"
Write-Host "Downloading and initializing the local Vietnamese voice model. This may take several minutes..."
& $pythonPath -c "from vieneu import Vieneu; Vieneu(device='cpu', backend='onnx'); print('VieNeu model is ready for local CPU inference.')"
if ($LASTEXITCODE -ne 0) {
    throw "VieNeu could not load its model. Check the internet connection and available disk space, then rerun this script."
}

[Environment]::SetEnvironmentVariable("VIENEU_PYTHON", $pythonPath, "User")
Write-Host "Voice setup is complete. Restart the app to use the local voice clone."
