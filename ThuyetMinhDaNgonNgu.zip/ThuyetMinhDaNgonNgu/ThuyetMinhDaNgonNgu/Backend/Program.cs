using ThuyetMinhDaNgonNgu.Frontend.Components;
using ThuyetMinhDaNgonNgu.Backend.Services;

var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    Args = args,
    WebRootPath = Path.Combine("Frontend", "wwwroot")
});

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddMemoryCache();
builder.Services.AddHttpClient<GeminiNarrationService>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(40);
});
builder.Services.AddHttpClient(nameof(VieNeuVietnameseTextToSpeechService), client =>
{
    client.Timeout = TimeSpan.FromMinutes(3);
});
builder.Services.AddSingleton<VieNeuVietnameseTextToSpeechService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseAntiforgery();
app.UseStaticFiles();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
