window.travelGuide = (() => {
    let utterance;
    let narrationAudio;
    let map;
    let mapProvider;
    let mapElement;
    let markers = new Map();
    let markerClusterer;
    let leafletMarkerLayer;
    let leafletBaseLayers;
    let leafletActiveLayer;
    let infoWindow;
    let userMarker;
    let mapPlaces = [];
    let visiblePlaceIds = new Set();
    let dotNetReference;
    let mapsLoadPromise;
    const vietnamBounds = { north: 23.5, south: 8.3, east: 109.6, west: 102.1 };

    function showMapError(message) {
        if (!mapElement) {
            return;
        }

        const notice = document.createElement("div");
        notice.className = "map-error";
        notice.setAttribute("role", "alert");
        notice.textContent = message;
        mapElement.replaceChildren(notice);
    }

    function ensureGoogleMaps(apiKey) {
        if (window.google?.maps) {
            return Promise.resolve();
        }

        if (!apiKey) {
            return Promise.reject(new Error(
                "Chưa cấu hình Google Maps API key. Hãy xem hướng dẫn trong README.md."));
        }

        if (!mapsLoadPromise) {
            const callbackName = "__travelGuideGoogleMapsLoaded";
            mapsLoadPromise = new Promise((resolve, reject) => {
                const script = document.createElement("script");
                const timeout = window.setTimeout(() => {
                    delete window[callbackName];
                    script.remove();
                    reject(new Error("Google Maps tải quá lâu. Hãy kiểm tra kết nối mạng rồi tải lại trang."));
                }, 15000);

                window[callbackName] = () => {
                    window.clearTimeout(timeout);
                    delete window[callbackName];
                    resolve();
                };

                script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly&callback=${callbackName}`;
                script.async = true;
                script.onerror = () => {
                    window.clearTimeout(timeout);
                    delete window[callbackName];
                    script.remove();
                    reject(new Error("Không thể tải Google Maps. Hãy kiểm tra kết nối mạng và thử lại."));
                };
                document.head.append(script);
            }).catch((error) => {
                mapsLoadPromise = undefined;
                throw error;
            });
        }

        return mapsLoadPromise;
    }

    function createPlaceIcon(place, selectedId) {
        const color = place.id === selectedId ? "#bc5e43" : "#d97658";
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="48" viewBox="0 0 40 48"><path d="M20 1C9 1 1 9 1 19c0 13 19 28 19 28s19-15 19-28C39 9 31 1 20 1Z" fill="${color}" stroke="#fffefa" stroke-width="2"/><text x="20" y="25" text-anchor="middle" font-size="16">${place.icon}</text></svg>`;
        return {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`,
            scaledSize: new google.maps.Size(36, 43),
            anchor: new google.maps.Point(18, 42)
        };
    }

    function createLeafletPlaceIcon(place, selectedId) {
        const pin = document.createElement("span");
        pin.className = `destination-marker__pin${place.id === selectedId ? " destination-marker__pin--selected" : ""}`;
        const glyph = document.createElement("span");
        glyph.className = "destination-marker__glyph";
        glyph.textContent = place.icon;
        pin.append(glyph);

        return L.divIcon({
            className: "destination-marker",
            html: pin,
            iconSize: [36, 42],
            iconAnchor: [18, 39]
        });
    }

    function updateSelectedMarker(selectedId) {
        for (const place of mapPlaces) {
            const marker = markers.get(place.id);
            if (marker) {
                marker.setIcon(mapProvider === "google"
                    ? createPlaceIcon(place, selectedId)
                    : createLeafletPlaceIcon(place, selectedId));
            }
        }
    }

    function initializeClusters() {
        const MarkerClusterer = window.markerClusterer?.MarkerClusterer;
        if (!MarkerClusterer) {
            for (const marker of markers.values()) {
                marker.setMap(map);
            }
            return;
        }

        markerClusterer = new MarkerClusterer({
            map,
            markers: Array.from(markers.values()),
            renderer: {
                render: ({ count, position }) => new google.maps.Marker({
                    position,
                    label: {
                        text: String(count),
                        color: "#ffffff",
                        fontSize: "12px",
                        fontWeight: "700"
                    },
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 18,
                        fillColor: "#ca694c",
                        fillOpacity: 1,
                        strokeColor: "#ffffff",
                        strokeWeight: 2
                    },
                    zIndex: Number(google.maps.Marker.MAX_ZINDEX) + count
                })
            }
        });
    }

    function initializeFreeMap(element, places, selectedId) {
        if (!window.L) {
            showMapError("Không tải được bản đồ. Hãy kiểm tra kết nối mạng rồi tải lại trang.");
            return;
        }

        mapProvider = "leaflet";
        map = L.map(element, {
            attributionControl: true,
            zoomControl: true,
            scrollWheelZoom: true
        });
        leafletBaseLayers = {
            roadmap: L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                maxZoom: 19,
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>'
            }),
            hybrid: L.tileLayer(
                "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                {
                    maxZoom: 19,
                    attribution: 'Tiles &copy; Esri, Maxar, Earthstar Geographics, and the GIS User Community'
                })
        };
        leafletActiveLayer = leafletBaseLayers.roadmap.addTo(map);

        leafletMarkerLayer = window.L.markerClusterGroup
            ? L.markerClusterGroup({
                showCoverageOnHover: false,
                spiderfyOnMaxZoom: true,
                disableClusteringAtZoom: 9,
                maxClusterRadius: 44,
                iconCreateFunction: (cluster) => L.divIcon({
                    className: "destination-cluster",
                    html: `<span>${cluster.getChildCount()}</span>`,
                    iconSize: [36, 36]
                })
            })
            : L.layerGroup();

        for (const place of places) {
            const marker = L.marker([place.latitude, place.longitude], {
                icon: createLeafletPlaceIcon(place, selectedId),
                title: place.name,
                alt: place.name
            });
            marker.bindTooltip(place.name, { direction: "top", offset: [0, -29] });
            marker.on("click", () => {
                updateSelectedMarker(place.id);
                marker.openTooltip();
                dotNetReference.invokeMethodAsync("OnMapPlaceSelectedAsync", place.id);
            });
            markers.set(place.id, marker);
            leafletMarkerLayer.addLayer(marker);
        }

        map.addLayer(leafletMarkerLayer);
        visiblePlaceIds = new Set(places.map((place) => place.id));
        map.fitBounds([[8.3, 102.1], [23.5, 109.6]], { padding: [24, 32], maxZoom: 7 });
        window.setTimeout(() => map.invalidateSize(), 0);
    }

    async function initializeMap(element, places, selectedId, apiKey, reference) {
        mapElement = element;
        dotNetReference = reference;
        mapPlaces = places;
        markers.clear();
        markerClusterer = undefined;
        leafletMarkerLayer = undefined;
        if (!apiKey) {
            initializeFreeMap(element, places, selectedId);
            return;
        }

        window.gm_authFailure = () => showMapError(
            "Google Maps không chấp nhận API key. Hãy kiểm tra quyền API và giới hạn tên miền trong Google Cloud.");

        try {
            await ensureGoogleMaps(apiKey);
        } catch (error) {
            showMapError(error.message);
            return;
        }

        if (!element.isConnected) {
            return;
        }

        mapProvider = "google";
        map = new google.maps.Map(element, {
            center: { lat: 16.5, lng: 106.5 },
            zoom: 5,
            mapTypeId: "roadmap",
            mapTypeControl: false,
            fullscreenControl: true,
            streetViewControl: false,
            zoomControl: true,
            gestureHandling: "greedy"
        });
        infoWindow = new google.maps.InfoWindow();

        for (const place of places) {
            const marker = new google.maps.Marker({
                position: { lat: place.latitude, lng: place.longitude },
                title: place.name,
                icon: createPlaceIcon(place, selectedId)
            });
            marker.addListener("click", () => {
                updateSelectedMarker(place.id);
                const label = document.createElement("span");
                label.textContent = place.name;
                infoWindow.setContent(label);
                infoWindow.open({ map, anchor: marker });
                dotNetReference.invokeMethodAsync("OnMapPlaceSelectedAsync", place.id);
            });
            markers.set(place.id, marker);
        }

        initializeClusters();
        visiblePlaceIds = new Set(places.map((place) => place.id));
        map.fitBounds(vietnamBounds, 24);
    }

    function setMapType(mapType) {
        if (!map || (mapType !== "roadmap" && mapType !== "hybrid")) {
            return;
        }

        if (mapProvider === "google") {
            map.setMapTypeId(mapType);
        } else if (leafletBaseLayers[mapType] !== leafletActiveLayer) {
            map.removeLayer(leafletActiveLayer);
            leafletActiveLayer = leafletBaseLayers[mapType].addTo(map);
        }
    }

    function updateVisiblePlaces(visibleIds) {
        const visible = new Set(visibleIds);
        const added = mapPlaces
            .filter((place) => visible.has(place.id) && !visiblePlaceIds.has(place.id))
            .map((place) => markers.get(place.id))
            .filter(Boolean);
        const removed = mapPlaces
            .filter((place) => !visible.has(place.id) && visiblePlaceIds.has(place.id))
            .map((place) => markers.get(place.id))
            .filter(Boolean);
        visiblePlaceIds = visible;

        if (mapProvider === "leaflet") {
            for (const marker of removed) {
                leafletMarkerLayer.removeLayer(marker);
            }
            for (const marker of added) {
                leafletMarkerLayer.addLayer(marker);
            }
        } else if (markerClusterer) {
            markerClusterer.removeMarkers(removed, true);
            markerClusterer.addMarkers(added, true);
            if (added.length || removed.length) {
                markerClusterer.render();
            }
        } else {
            for (const place of mapPlaces) {
                markers.get(place.id)?.setMap(visible.has(place.id) ? map : null);
            }
        }
    }

    function selectPlace(placeId) {
        const place = mapPlaces.find((item) => item.id === placeId);
        const marker = markers.get(placeId);
        if (!place || !map || !marker) {
            return;
        }

        updateSelectedMarker(placeId);
        if (mapProvider === "leaflet") {
            map.setView([place.latitude, place.longitude], Math.max(map.getZoom(), 13));
            marker.openTooltip();
        } else {
            map.panTo({ lat: place.latitude, lng: place.longitude });
            map.setZoom(Math.max(map.getZoom(), 13));
            const label = document.createElement("span");
            label.textContent = place.name;
            infoWindow.setContent(label);
            infoWindow.open({ map, anchor: marker });
        }
    }

    function resetMap() {
        if (!map) {
            return;
        }

        if (mapProvider === "leaflet") {
            map.fitBounds([[8.3, 102.1], [23.5, 109.6]], { padding: [24, 32], maxZoom: 7 });
        } else {
            map.fitBounds(vietnamBounds, 24);
        }
        if (userMarker) {
            if (mapProvider === "leaflet") {
                userMarker.remove();
            } else {
                userMarker.setMap(null);
            }
            userMarker = undefined;
        }
        infoWindow?.close();
        updateSelectedMarker(mapPlaces[0]?.id);
    }

    function getNearbyPlaces(latitude, longitude) {
        const toRadians = (degrees) => degrees * Math.PI / 180;
        const earthRadiusKm = 6371;

        return mapPlaces
            .map((place) => {
                const latitudeDelta = toRadians(place.latitude - latitude);
                const longitudeDelta = toRadians(place.longitude - longitude);
                const haversine = Math.sin(latitudeDelta / 2) ** 2 +
                    Math.cos(toRadians(latitude)) *
                    Math.cos(toRadians(place.latitude)) *
                    Math.sin(longitudeDelta / 2) ** 2;
                const distanceKm = 2 * earthRadiusKm *
                    Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine));
                return { place, distanceKm };
            })
            .filter((item) => item.distanceKm <= 50)
            .sort((left, right) => left.distanceKm - right.distanceKm)
            .slice(0, 5)
            .map((item) => item.place);
    }

    function zoomToNearbyArea(latitude, longitude) {
        const nearbyPlaces = getNearbyPlaces(latitude, longitude);
        if (mapProvider === "leaflet") {
            if (nearbyPlaces.length === 0) {
                map.setView([latitude, longitude], 13);
                return;
            }

            const bounds = L.latLngBounds([[latitude, longitude]]);
            for (const place of nearbyPlaces) {
                bounds.extend([place.latitude, place.longitude]);
            }
            map.fitBounds(bounds, { padding: [48, 48], maxZoom: 12 });
            return;
        }

        const userLocation = { lat: latitude, lng: longitude };
        if (nearbyPlaces.length === 0) {
            map.setCenter(userLocation);
            map.setZoom(13);
            return;
        }

        const bounds = new google.maps.LatLngBounds();
        bounds.extend(userLocation);
        for (const place of nearbyPlaces) {
            bounds.extend({ lat: place.latitude, lng: place.longitude });
        }
        map.fitBounds(bounds, 48);
        google.maps.event.addListenerOnce(map, "bounds_changed", () => {
            if (map.getZoom() > 12) {
                map.setZoom(12);
            }
        });
    }

    function stopNarration() {
        if ("speechSynthesis" in window) {
            window.speechSynthesis.cancel();
        }

        if (narrationAudio) {
            narrationAudio.pause();
            narrationAudio.removeAttribute("src");
            narrationAudio.load();
            narrationAudio = undefined;
        }

        utterance = undefined;
    }

    function pauseNarration() {
        if (narrationAudio) {
            narrationAudio.pause();
            return true;
        }
        if (utterance && "speechSynthesis" in window) {
            window.speechSynthesis.pause();
            return true;
        }
        return false;
    }

    async function resumeNarration() {
        if (narrationAudio?.paused) {
            try {
                await narrationAudio.play();
                return true;
            } catch {
                return false;
            }
        }
        if (utterance && "speechSynthesis" in window) {
            window.speechSynthesis.resume();
            return true;
        }
        return false;
    }

    async function startLocalNarration(audioContent, dotNetReference) {
        stopNarration();
        narrationAudio = new Audio(`data:audio/wav;base64,${audioContent}`);
        narrationAudio.onended = () => dotNetReference.invokeMethodAsync("OnNarrationEndedAsync");
        narrationAudio.onerror = () => dotNetReference.invokeMethodAsync("OnNarrationEndedAsync");

        try {
            await narrationAudio.play();
            return true;
        } catch (error) {
            narrationAudio.removeAttribute("src");
            narrationAudio.load();
            narrationAudio = undefined;
            return false;
        }
    }

    function loadSpeechVoices(speechSynthesis) {
        const voices = speechSynthesis.getVoices();
        if (voices.length > 0) {
            return Promise.resolve(voices);
        }

        return new Promise((resolve) => {
            const finish = () => {
                window.clearTimeout(timeout);
                speechSynthesis.removeEventListener("voiceschanged", onVoicesChanged);
                resolve(speechSynthesis.getVoices());
            };
            const onVoicesChanged = () => {
                if (speechSynthesis.getVoices().length > 0) {
                    finish();
                }
            };
            const timeout = window.setTimeout(finish, 3000);
            speechSynthesis.addEventListener("voiceschanged", onVoicesChanged);
        });
    }

    async function startNarration(text, language, dotNetReference) {
        if (!("speechSynthesis" in window)) {
            return false;
        }

        const voiceLanguages = {
            vi: "vi-VN",
            en: "en-US",
            zh: "zh-CN",
            ja: "ja-JP",
            ko: "ko-KR"
        };
        const languageTag = voiceLanguages[language];
        if (!languageTag) {
            return false;
        }

        stopNarration();
        const voices = await loadSpeechVoices(window.speechSynthesis);
        const languagePrefix = languageTag.split("-")[0].toLowerCase();
        const matchingVoice = voices.find((voice) =>
            voice.lang.toLowerCase() === languageTag.toLowerCase()) ??
            voices.find((voice) =>
                voice.lang.split("-")[0].toLowerCase() === languagePrefix);
        if (!matchingVoice) {
            return false;
        }

        utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = languageTag;
        utterance.voice = matchingVoice;
        utterance.rate = language === "ja" ? 1.02 : 0.94;
        utterance.pitch = language === "ja" ? 1.18 : 1;
        utterance.onend = () => {
            utterance = undefined;
            dotNetReference.invokeMethodAsync("OnNarrationEndedAsync");
        };
        utterance.onerror = (event) => {
            if (event.error === "canceled" || event.error === "interrupted") {
                return;
            }
            utterance = undefined;
            dotNetReference.invokeMethodAsync("OnNarrationErrorAsync", event.error || "synthesis-failed");
        };
        try {
            window.speechSynthesis.speak(utterance);
            return true;
        } catch {
            utterance = undefined;
            return false;
        }
    }

    function findLocation(dotNetReference) {
        if (!map) {
            dotNetReference.invokeMethodAsync("OnLocationResultAsync", "unavailable");
            return;
        }

        if (!("geolocation" in navigator)) {
            dotNetReference.invokeMethodAsync("OnLocationResultAsync", "unsupported");
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                if (mapProvider === "leaflet") {
                    zoomToNearbyArea(latitude, longitude);
                    if (userMarker) {
                        userMarker.setLatLng([latitude, longitude]);
                    } else {
                        const marker = document.createElement("span");
                        marker.className = "map-user-dot";
                        userMarker = L.marker([latitude, longitude], {
                            icon: L.divIcon({
                                className: "map-user-marker",
                                html: marker,
                                iconSize: [22, 22],
                                iconAnchor: [11, 11]
                            }),
                            title: "Vị trí của bạn"
                        }).addTo(map);
                    }
                    dotNetReference.invokeMethodAsync("OnLocationResultAsync", "located");
                    return;
                }

                const userLocation = { lat: latitude, lng: longitude };
                zoomToNearbyArea(latitude, longitude);
                if (userMarker) {
                    userMarker.setPosition(userLocation);
                } else {
                    userMarker = new google.maps.Marker({
                        position: userLocation,
                        map,
                        title: "Vị trí của bạn",
                        icon: {
                            path: google.maps.SymbolPath.CIRCLE,
                            scale: 8,
                            fillColor: "#488dc5",
                            fillOpacity: 1,
                            strokeColor: "#ffffff",
                            strokeWeight: 3
                        },
                        zIndex: 1000
                    });
                }
                dotNetReference.invokeMethodAsync("OnLocationResultAsync", "located");
            },
            (error) => {
                const result = error.code === error.PERMISSION_DENIED ? "denied" : "unavailable";
                dotNetReference.invokeMethodAsync("OnLocationResultAsync", result);
            },
            { enableHighAccuracy: false, timeout: 12000, maximumAge: 30000 }
        );
    }

    function loadPreferences() {
        const saved = localStorage.getItem("dau-chan-viet.preferences.v1");
        return saved ? JSON.parse(saved) : null;
    }

    function savePreferences(language, savedPlaceIds) {
        localStorage.setItem("dau-chan-viet.preferences.v1", JSON.stringify({
            language,
            savedPlaceIds
        }));
    }

    return {
        findLocation,
        initializeMap,
        loadPreferences,
        pauseNarration,
        resetMap,
        resumeNarration,
        savePreferences,
        selectPlace,
        setMapType,
        startLocalNarration,
        startNarration,
        stopNarration,
        updateVisiblePlaces
    };
})();
