# Phân tích đồ án — Frontend

## Phạm vi và lưu ý

Tài liệu này tổng hợp phần frontend được mô tả trong `system-presentation-standalone (1).html`, với chủ đề **Hệ Thống Du Lịch Ẩm Thực Quận 4**. Đây là nội dung của bản trình bày; file không kèm mã nguồn frontend để xác minh các tính năng đã chạy hoàn chỉnh hay mới ở mức thiết kế.

## Những phần đã được mô tả

- **PWA khám phá ẩm thực Quận 4:** giao diện bản đồ tương tác, thông tin POI (địa điểm), hình ảnh, nội dung đa ngôn ngữ và thuyết minh âm thanh.
- **Bản đồ online/offline/hybrid:** hỗ trợ bản đồ cloud, gói bản đồ offline PMTiles và chế độ hybrid ưu tiên cloud rồi chuyển sang dữ liệu local khi mất mạng. Luồng tải gói có manifest, kiểm tra SHA-256 và cập nhật an toàn trước khi kích hoạt.
- **Vị trí và geofence:** lấy vị trí theo cơ chế best-effort, phát hiện người dùng vào/ra vùng POI, có debounce, giới hạn tần suất cập nhật GPS và thời gian cooldown.
- **Phát thuyết minh theo nhiều tầng:** ưu tiên audio đã có, sau đó localization/audio on-demand, TTS từ backend và fallback được mô tả trong luồng hybrid.
- **Đa ngôn ngữ:** tách nội dung POI theo locale khỏi bản dịch giao diện; có hotset, tải theo yêu cầu và warmup nền trước/sau khi đổi ngôn ngữ.
- **Khởi động nhanh và đồng bộ dữ liệu:** hiển thị snapshot POI/UI đã lưu trong IndexedDB trước khi backend phản hồi; hỗ trợ full sync hoặc delta sync dựa trên ETag, version và cursor.
- **Offline/PWA nhiều lớp:** Service Worker quản lý cache POI, audio theo ngôn ngữ, ảnh, runtime chunks và map pack; IndexedDB làm lớp dự phòng; offline pack đóng gói map, POI, ảnh và audio.
- **Giao diện quản trị và chủ quán:** bản trình bày nêu Admin Dashboard, Owner Portal, theo dõi tác vụ audio và tiến độ, cùng luồng đăng ký/chờ duyệt chủ quán.

## Công nghệ và chi tiết frontend được nêu

- MapLibre và PMTiles cho bản đồ/gói bản đồ.
- Service Worker, Cache API và IndexedDB (được gọi là `Quan4DB v2`) cho lưu trữ và hoạt động offline.
- Các service/luồng frontend được nhắc tên: `LocationService`, `GeofenceEngine`, `NarrationEngine`, `AudioQueueManager`, `MapPackService` và `AudioPackService`.
- Giao tiếp với API qua các luồng như `/poi/load-all`, `/poi/nearby`, `/localizations/on-demand`, `/warmup`, `/audio/tts` và các API map/audio pack.

## Đánh giá tình trạng

Thiết kế frontend được trình bày khá sâu: có luồng khởi động, chiến lược cache, đồng bộ, fallback, xử lý GPS và cập nhật map/audio pack. Tuy nhiên, HTML **không có danh sách việc đã hoàn tất/chưa hoàn tất, ảnh chụp kiểm thử, mã nguồn hoặc kết quả chạy**. Vì vậy chỉ có thể xác nhận các chức năng trên đã được đặc tả trong bản trình bày, không thể khẳng định chúng đã được triển khai đầy đủ.

## Cần kiểm tra để xác nhận hoàn thành

1. Chạy PWA trên thiết bị thật và kiểm tra quyền GPS, geofence, đổi locale khi audio đang phát.
2. Thử offline sau khi cài từng loại pack; kiểm tra tải mới, cập nhật, sửa chữa và gỡ pack.
3. Kiểm tra đồng bộ full/delta, cache miss, dữ liệu stale và fallback khi API không khả dụng.
4. Xác nhận các màn hình Admin/Owner, tiến độ tác vụ audio và thông báo lỗi hoạt động với backend thật.
