# Phân tích đồ án — Backend

## Phạm vi và lưu ý

Tài liệu này tổng hợp phần backend được mô tả trong `system-presentation-standalone (1).html`, với chủ đề **Hệ Thống Du Lịch Ẩm Thực Quận 4**. Đây là nội dung của bản trình bày; không có mã nguồn backend đi kèm trong file để xác minh các endpoint hoặc dịch vụ đã được triển khai và kiểm thử.

## Những phần đã được mô tả

- **Kiến trúc dịch vụ:** backend chia thành 10 router/lane: `content`, `audio`, `admin`, `owner`, `ai_advisor`, `analytics`, `localization`, `maps`, `runtime_observability` và `ui_i18n`. Các lane dùng chung MongoDB, Redis và lưu trữ static/runtime nhưng được chia boundary theo router/service/store.
- **Khởi động và sẵn sàng phục vụ:** kiểm tra secret và chế độ bootstrap, kết nối database/cache/media, seed role và super-admin, xác nhận runtime storage, khôi phục tác vụ audio sau restart, khởi chạy worker và cung cấp health/readiness.
- **Quản lý POI:** mô hình dữ liệu POI, bản dịch, menu, chủ quán và submission chờ duyệt; CRUD, kích hoạt có điều kiện theo mức độ sẵn sàng của nội dung/audio, xóa liên quan và cập nhật version dữ liệu.
- **Đọc và đồng bộ nội dung:** `/poi/load-all` hỗ trợ full/delta sync với ETag, `dataset_version`, `updated_after` và cursor; `/poi/nearby` ưu tiên truy vấn địa lý và có fallback tính khoảng cách.
- **Localization và giao diện đa ngôn ngữ:** nội dung POI và UI bundle được xử lý riêng; có on-demand translation, warmup toàn bộ, cache, rate limit và `Retry-After`.
- **Audio/TTS:** mô tả tạo audio bằng Edge-TTS, cache theo nội dung/ngôn ngữ, tạo hàng loạt qua background task, giới hạn song song, SSE theo dõi tiến độ, API TTS trực tiếp và manifest cho audio pack.
- **Đăng nhập và phân quyền:** JWT trong cookie `httpOnly`, refresh token, chế độ xác thực dự phòng cho API/mobile, role động trong MongoDB và kiểm tra quyền theo permission domain.
- **Bản đồ và static assets:** manifest/options, PMTiles có Range Requests, style/sprite/glyph, đường dẫn static và API tương thích cho map packs.
- **Cổng quản trị/chủ quán và AI:** quy trình đăng ký chủ quán, admin duyệt, giới hạn chủ quán quản lý POI của mình; tài liệu cũng nêu AI Advisor dùng Gemini 2.5 Flash/ProxyPal.
- **Quan sát và vận hành:** readiness, analytics worker, runtime observability, media cleanup, recovery và retention tác vụ được đưa vào luồng vận hành.

## Dữ liệu và công nghệ được nêu

- **MongoDB:** POI/localization, tác vụ audio, tài khoản, role, đăng ký chủ quán, submissions, notifications, rate limits và UI bundles.
- **Redis:** được nêu là thành phần dùng chung cho cache/runtime; một số quota/rate limit có shared state.
- **Lưu trữ media/static:** gồm audio, ảnh, map assets và runtime storage; có đề cập tùy chọn S3-compatible storage.
- **Dịch vụ ngoài:** Edge-TTS cho audio và Gemini/ProxyPal cho AI Advisor; cloud map cần cấu hình key theo mô tả bản trình bày.

## Đánh giá tình trạng

Backend có đặc tả kiến trúc và vận hành tương đối chi tiết, gồm router, collection, endpoint, quy trình khởi động, bảo mật, đồng bộ và worker. Dù vậy, HTML **không phân loại tính năng theo trạng thái hoàn thành**, cũng không cung cấp source code, test report, log triển khai hay cấu hình môi trường. Do đó chưa thể kết luận backend đã tồn tại đúng như mô tả hoặc đang chạy ổn định.

## Cần kiểm tra để xác nhận hoàn thành

1. Đối chiếu từng router/endpoint được liệt kê với mã nguồn và OpenAPI hoặc bộ sưu tập request.
2. Chạy test cho CRUD POI, delta sync, geospatial query/fallback, RBAC và luồng duyệt chủ quán.
3. Kiểm tra restart recovery, retry/rate limit, worker audio, SSE và dọn media.
4. Kiểm tra secret/bootstrap fail-fast, cookie flags, transaction readiness, health/readiness và cấu hình lưu trữ.
5. Xác nhận các dịch vụ Edge-TTS, Gemini/ProxyPal, Redis và map asset có cấu hình/deployment tương ứng.
