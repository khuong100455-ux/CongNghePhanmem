# Dấu Chân Việt

Ứng dụng frontend C# / Blazor khám phá các điểm đến du lịch trên khắp Việt Nam.
Bản đồ trực tuyến hiển thị các điểm đến tương tác, cụm điểm đánh dấu và lựa
chọn chế độ đường/vệ tinh. Không cần API key để dùng bản đồ mặc định.

Khi không cấu hình Google Maps, ứng dụng dùng OpenStreetMap cho bản đồ đường và
ảnh vệ tinh Esri; cần kết nối Internet và hiển thị thông tin ghi công trên bản
đồ. Nếu cấu hình Google Maps API key bên dưới, bản đồ Google được dùng thay
cho bản đồ dự phòng. Chọn địa danh để đọc thuyết minh bằng tiếng Việt, Anh,
Trung, Nhật hoặc Hàn. Nút vị trí chỉ truy cập GPS sau khi người dùng chủ động
bấm và đồng ý với trình duyệt. Nhà cung cấp bản đồ có thể nhận yêu cầu tải khu
vực đang xem. Ứng dụng không lưu tọa độ trên máy chủ. Điểm đến và lời dẫn là
minh họa, không phải danh bạ đã xác minh hay chỉ đường thực tế.

Ngôn ngữ đã chọn và danh sách địa điểm yêu thích được lưu trong local storage
của trình duyệt trên thiết bị hiện tại. Nút chỉ đường mở Google Maps với điểm
đến đang chọn; đây là liên kết chỉ đường bên ngoài, không phải lộ trình do ứng
dụng tự tính.

## Cấu trúc mã nguồn

- `ThuyetMinhDaNgonNgu\Frontend\Components`: giao diện Blazor, layout và trang.
- `ThuyetMinhDaNgonNgu\Frontend\wwwroot`: CSS, JavaScript và tài nguyên trình duyệt.
- `ThuyetMinhDaNgonNgu\Backend`: điểm khởi chạy ứng dụng, dịch vụ Gemini/VieNeu và script TTS.
- File `.csproj` cùng `appsettings*.json` được giữ ở thư mục gốc của dự án để cấu hình và chạy ứng dụng.

## Cấu hình Google Maps

1. Tạo hoặc chọn một dự án trong [Google Cloud Console](https://console.cloud.google.com/).
2. Bật **Maps JavaScript API** và liên kết tài khoản thanh toán theo yêu cầu
   của Google.
3. Tạo API key, giới hạn key cho **Maps JavaScript API** và giới hạn website
   (HTTP referrers) như `http://localhost:5100/*` và
   `http://127.0.0.1:5100/*`. Thêm tên miền website khi triển khai thật.
4. Đặt key trong cùng cửa sổ PowerShell dùng để chạy ứng dụng:

```powershell
$env:GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY"
dotnet run --project .\ThuyetMinhDaNgonNgu\ThuyetMinhDaNgonNgu.csproj --urls http://127.0.0.1:5100
```

Google Maps JavaScript API key xuất hiện trong yêu cầu tải bản đồ ở trình
duyệt; đây là cách API hoạt động. Vì vậy, chỉ dùng key đã giới hạn theo API và
website, theo dõi quota/chi phí trong Google Cloud, và không commit key vào mã
nguồn. Nếu chưa cấu hình key, bản đồ dự phòng vẫn hoạt động mà không cần bật
billing hoặc Google Maps API.

## Tạo thuyết minh bằng Gemini

Chọn ngôn ngữ ở góc trên, chọn một địa danh rồi bấm **Tạo thuyết minh bằng AI**.
Gemini tạo lời dẫn bằng ngôn ngữ đã chọn. Phần mô tả địa danh gửi tới Gemini;
tọa độ GPS của người dùng không được gửi. Yêu cầu Gemini không được lưu để tiếp
tục hội thoại.

Tạo API key trong Google AI Studio, sau đó cấu hình biến môi trường trong cùng
cửa sổ PowerShell dùng để chạy ứng dụng:

```powershell
$env:GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
dotnet run --project .\ThuyetMinhDaNgonNgu\ThuyetMinhDaNgonNgu.csproj
```

Không dán API key vào ứng dụng trình duyệt, commit vào mã nguồn hoặc chia sẻ
trong cuộc trò chuyện. Mặc định ứng dụng dùng `gemini-3.1-flash-lite`. Có thể
chọn model khác được Gemini hỗ trợ bằng biến môi trường `GEMINI_MODEL`.

## Giọng đọc tiếng Việt theo file mẫu

Tiếng Việt dùng VieNeu-TTS để tạo lời đọc theo giọng trong file mẫu, chạy cục
bộ trên CPU qua ONNX Runtime. Ứng dụng giữ file mẫu, nội dung và âm thanh đã
tạo trên máy; tiến trình TTS chỉ lắng nghe `127.0.0.1`, không gửi file giọng
hoặc văn bản tới nhà cung cấp TTS. Nếu bật Gemini để viết lời thuyết minh AI,
nội dung địa danh vẫn được gửi tới Gemini; GPS không được gửi.

Mẫu tốt nhất là thoại rõ của một người, tối thiểu 3 giây. Script dùng 8 giây
đầu tiên, chuyển thành WAV mono rồi lưu riêng trong
`%LOCALAPPDATA%\DauChanViet\VieNeu`. Không đưa file giọng cá nhân vào mã nguồn
hoặc Git. Chỉ dùng giọng của bạn hoặc giọng bạn có quyền sử dụng.

Chạy script PowerShell kèm theo, truyền đường dẫn file WAV, MP3 hoặc FLAC:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\ThuyetMinhDaNgonNgu\Backend\Setup-VieNeu.ps1 -ReferenceAudioPath "C:\duong-dan\voice-sample.mp3"
```

Script cài Python 3.12 nếu chưa có, cài SDK `vieneu`, chuẩn bị mẫu giọng và
tải model lần đầu (vài trăm MB). PowerShell `-ExecutionPolicy Bypass` chỉ áp
dụng cho tiến trình cài đặt này, không đổi chính sách hệ thống. Khởi động lại
ứng dụng sau khi hoàn tất. Model được phân phối theo Apache-2.0; xem
[VieNeu-TTS](https://github.com/pnnbao97/VieNeu-TTS) và
[model card](https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo).

## Chạy ứng dụng

Yêu cầu .NET 10 SDK:

```powershell
dotnet run --project .\ThuyetMinhDaNgonNgu\ThuyetMinhDaNgonNgu.csproj
```

Mở địa chỉ localhost được in ra trong terminal. Giọng tiếng Anh, Trung, Nhật
và Hàn sử dụng giọng đọc có sẵn trên thiết bị; hãy cài giọng đọc đúng ngôn ngữ
trong cài đặt hệ điều hành. Ứng dụng không cố dùng giọng ngôn ngữ khác nếu
thiết bị chưa có giọng phù hợp. Với VieNeu, chất lượng phát âm phụ thuộc nhiều
vào giọng mẫu: hãy dùng mẫu thoại tiếng Việt rõ ràng, tự nhiên, không lẫn tiếng
Anh, và phát âm đầy đủ tên riêng/từ mượn cần đọc. VieNeu là giọng nhân bản từ
mẫu, không phải bộ hiệu chỉnh phát âm sau khi tổng hợp. Nếu chưa
cấu hình `GEMINI_API_KEY`, phần nghe mẫu vẫn hoạt động, còn nút Gemini sẽ hiển
thị hướng dẫn cấu hình.
