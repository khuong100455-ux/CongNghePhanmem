import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { ttsPlugin } from './server/ttsPlugin.js'

export default defineConfig({
  plugins: [react(), ttsPlugin()],
  server: {
    host: '127.0.0.1',
    port: 5174,
    strictPort: true,
  },
})
