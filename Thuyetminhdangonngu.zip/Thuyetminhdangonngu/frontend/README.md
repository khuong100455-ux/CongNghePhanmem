# Frontend — Thuyết minh đa ngôn ngữ

Chạy **độc lập**, chưa cần backend. Dữ liệu điểm nằm trong `src/data/seedPois.js` và `localStorage`. Khi có FastAPI, chỉ thay `src/services/mockApi.js`.

## Chạy

```bash
cd frontend
npm install
npm run dev
```

Mở http://localhost:5173

- App khách: chọn ngôn ngữ → bản đồ / danh sách → nghe thuyết minh
- Admin: `admin` / `thuyetminh`
- Bảo vệ trong phòng: bật **Giả lập vị trí** rồi đặt GPS vào một điểm (geofence tự phát)

Giọng nói hiện tại dùng **TTS trình duyệt** (`speechSynthesis`) vì chưa có file MP3 từ server. Nhánh phát file (`audio_url`) đã để sẵn trong `narrationEngine.js`.
