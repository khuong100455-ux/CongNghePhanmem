import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useT } from '../hooks/useT'
import { api } from '../services/mockApi'
import { useAppStore } from '../store/useAppStore'

export default function AdminLoginPage() {
  const t = useT()
  const navigate = useNavigate()
  const lang = useAppStore((s) => s.lang) || 'vi'
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  async function onSubmit(e) {
    e.preventDefault()
    const res = await api.login(username.trim(), password)
    if (res.ok) navigate('/admin')
    else setError(t('loginError'))
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={onSubmit}>
        <div className="kicker">{t('admin')}</div>
        <h1 className="brand-title">{t('adminLogin')}</h1>
        <label>
          {t('username')}
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
        </label>
        <label>
          {t('password')}
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" type="submit" style={{ marginTop: '0.8rem' }}>
          {t('login')}
        </button>
        <p className="hint">{t('demoAccount')}</p>
        <p className="hint">
          <Link to={lang ? '/explore' : '/'}>{t('backPublic')}</Link>
        </p>
      </form>
    </div>
  )
}
