import { Link, Navigate, Outlet, useNavigate } from 'react-router-dom'
import { useT } from '../hooks/useT'
import { api } from '../services/mockApi'
import { useAppStore } from '../store/useAppStore'

export default function AdminLayout() {
  const t = useT()
  const navigate = useNavigate()
  const lang = useAppStore((s) => s.lang)
  if (!api.isAuthed()) return <Navigate to="/admin/login" replace />

  return (
    <div className="admin-shell">
      <aside className="side">
        <h2>{t('admin')}</h2>
        <Link to="/admin">{t('poiList')}</Link>
        <Link to="/admin/pois/new">{t('newPoi')}</Link>
        <Link to={lang ? '/explore' : '/'}>{t('backPublic')}</Link>
        <button
          className="linkish"
          type="button"
          onClick={() => {
            api.logout()
            navigate('/admin/login')
          }}
        >
          {t('logout')}
        </button>
      </aside>
      <main className="admin-main">
        <Outlet />
      </main>
    </div>
  )
}
