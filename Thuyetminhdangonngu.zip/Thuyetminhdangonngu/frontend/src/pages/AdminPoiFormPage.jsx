import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { SUPPORTED_LANGS } from '../data/seedPois'
import { useT } from '../hooks/useT'
import { api } from '../services/mockApi'
import { playNarration } from '../services/narrationEngine'
import { useAppStore } from '../store/useAppStore'

const empty = {
  id: '',
  lat: 10.7765,
  lng: 106.699,
  radius: 30,
  audio: { vi: 'missing', en: 'missing', ja: 'missing' },
  i18n: {
    vi: { title: '', description: '' },
    en: { title: '', description: '' },
    ja: { title: '', description: '' },
  },
}

export default function AdminPoiFormPage() {
  const { id } = useParams()
  const isNew = id === 'new'
  const t = useT()
  const navigate = useNavigate()
  const loadPois = useAppStore((s) => s.loadPois)
  const toastMsg = useAppStore((s) => s.toastMsg)
  const [poi, setPoi] = useState(empty)
  const [busyLang, setBusyLang] = useState('')

  useEffect(() => {
    if (isNew) {
      setPoi({ ...empty, id: `poi-${Date.now()}` })
      return
    }
    api.getPoi(id).then((found) => {
      if (found) setPoi(found)
    })
  }, [id, isNew])

  function patchI18n(lang, field, value) {
    setPoi((p) => ({
      ...p,
      i18n: { ...p.i18n, [lang]: { ...p.i18n[lang], [field]: value } },
    }))
  }

  async function onSave(e) {
    e.preventDefault()
    if (!poi.i18n.vi.title.trim() || !poi.i18n.vi.description.trim()) {
      toastMsg(t('needTitle'))
      return
    }
    await api.savePoi({
      ...poi,
      lat: Number(poi.lat),
      lng: Number(poi.lng),
      radius: Number(poi.radius),
    })
    await loadPois()
    toastMsg(t('saved'))
    navigate('/admin')
  }

  async function onGenerate(lang) {
    setBusyLang(lang)
    await api.savePoi(poi)
    const next = await api.generateAudio(poi.id, lang)
    setPoi(next)
    await loadPois()
    toastMsg(t('audioDone'))
    setBusyLang('')
  }

  return (
    <>
      <h1>{isNew ? t('newPoi') : t('edit')}</h1>
      <form className="form" onSubmit={onSave}>
        <label>
          {t('titleVi')}
          <input value={poi.i18n.vi.title} onChange={(e) => patchI18n('vi', 'title', e.target.value)} />
        </label>
        <label>
          {t('descVi')}
          <textarea value={poi.i18n.vi.description} onChange={(e) => patchI18n('vi', 'description', e.target.value)} />
        </label>
        <label>
          {t('titleEn')}
          <input value={poi.i18n.en.title} onChange={(e) => patchI18n('en', 'title', e.target.value)} />
        </label>
        <label>
          {t('descEn')}
          <textarea value={poi.i18n.en.description} onChange={(e) => patchI18n('en', 'description', e.target.value)} />
        </label>
        <label>
          {t('titleJa')}
          <input value={poi.i18n.ja.title} onChange={(e) => patchI18n('ja', 'title', e.target.value)} />
        </label>
        <label>
          {t('descJa')}
          <textarea value={poi.i18n.ja.description} onChange={(e) => patchI18n('ja', 'description', e.target.value)} />
        </label>
        <div className="grid-2">
          <label>
            {t('lat')}
            <input type="number" step="0.0001" value={poi.lat} onChange={(e) => setPoi({ ...poi, lat: e.target.value })} />
          </label>
          <label>
            {t('lng')}
            <input type="number" step="0.0001" value={poi.lng} onChange={(e) => setPoi({ ...poi, lng: e.target.value })} />
          </label>
        </div>
        <label>
          {t('radius')} ({t('meters')})
          <input type="number" value={poi.radius} onChange={(e) => setPoi({ ...poi, radius: e.target.value })} />
        </label>

        {!isNew && (
          <div className="row">
            {SUPPORTED_LANGS.map((lang) => (
              <button
                key={lang}
                className="ghost"
                type="button"
                disabled={busyLang === lang}
                onClick={() => onGenerate(lang)}
              >
                {busyLang === lang ? t('generating') : `${t('generateAudio')} ${lang.toUpperCase()}`}
              </button>
            ))}
            <button className="ghost" type="button" onClick={() => playNarration(poi, 'vi')}>
              {t('preview')}
            </button>
          </div>
        )}

        <div className="row">
          <button className="primary" type="submit" style={{ width: 'auto' }}>
            {t('save')}
          </button>
          <button className="ghost" type="button" onClick={() => navigate('/admin')}>
            {t('cancel')}
          </button>
        </div>
      </form>
    </>
  )
}
