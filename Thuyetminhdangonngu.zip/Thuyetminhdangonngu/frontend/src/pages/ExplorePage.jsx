import { useEffect, useRef, useState } from 'react'
import { Link, Navigate } from 'react-router-dom'
import AudioPlayerBar from '../components/AudioPlayerBar'
import LangSwitcher from '../components/LangSwitcher'
import PoiList from '../components/PoiList'
import PoiMap from '../components/PoiMap'
import PoiSheet from '../components/PoiSheet'
import SimPanel from '../components/SimPanel'
import { useT } from '../hooks/useT'
import { createGeofenceEngine } from '../services/geofenceEngine'
import { startWatch } from '../services/locationService'
import { playNarration, subscribe, stopNarration } from '../services/narrationEngine'
import { useAppStore } from '../store/useAppStore'

export default function ExplorePage() {
  const t = useT()
  const lang = useAppStore((s) => s.lang)
  const loadPois = useAppStore((s) => s.loadPois)
  const pois = useAppStore((s) => s.pois)
  const view = useAppStore((s) => s.view)
  const setView = useAppStore((s) => s.setView)
  const gpsEnabled = useAppStore((s) => s.gpsEnabled)
  const setGpsEnabled = useAppStore((s) => s.setGpsEnabled)
  const autoNarrate = useAppStore((s) => s.autoNarrate)
  const setAutoNarrate = useAppStore((s) => s.setAutoNarrate)
  const setPosition = useAppStore((s) => s.setPosition)
  const userPosition = useAppStore((s) => s.userPosition)
  const simulated = useAppStore((s) => s.simulated)
  const toastMsg = useAppStore((s) => s.toastMsg)
  const toast = useAppStore((s) => s.toast)
  const online = useAppStore((s) => s.online)
  const setOnline = useAppStore((s) => s.setOnline)
  const setPlayer = useAppStore((s) => s.setPlayer)
  const selectPoi = useAppStore((s) => s.selectPoi)
  const [simOpen, setSimOpen] = useState(false)
  const engineRef = useRef(null)

  useEffect(() => {
    const unsub = subscribe(setPlayer)
    return () => {
      unsub()
      stopNarration()
    }
  }, [setPlayer])

  useEffect(() => {
    loadPois()
  }, [lang, loadPois])

  useEffect(() => {
    const on = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [setOnline])

  useEffect(() => {
    engineRef.current = createGeofenceEngine({
      getEnabled: () => useAppStore.getState().autoNarrate,
      onEnter: (poi) => {
        selectPoi(poi.id)
        playNarration(poi, useAppStore.getState().lang)
      },
    })
  }, [selectPoi])

  useEffect(() => {
    if (!gpsEnabled || simulated) return undefined
    return startWatch({
      onUpdate: setPosition,
      onError: () => toastMsg(t('noGps')),
    })
  }, [gpsEnabled, simulated, setPosition, toastMsg, t])

  useEffect(() => {
    if (!userPosition || !pois.length) return
    engineRef.current?.check(userPosition, pois)
  }, [userPosition, pois, autoNarrate])

  if (!lang) return <Navigate to="/" replace />

  return (
    <div className="explore">
      <header className="topbar">
        <div className="topbar-left">
          <h1>{t('appName')}</h1>
          <p>
            <span className={`status-dot ${online ? 'on' : 'off'}`} />
            {online ? t('online') : t('offline')}
            {userPosition ? ` · ${t('youAreHere')}` : ''}
          </p>
        </div>
        <div className="top-actions">
          <LangSwitcher compact />
          <div className="seg">
            <button className={view === 'map' ? 'on' : ''} type="button" onClick={() => setView('map')}>
              {t('map')}
            </button>
            <button className={view === 'list' ? 'on' : ''} type="button" onClick={() => setView('list')}>
              {t('list')}
            </button>
          </div>
          <button className={`chip ${gpsEnabled ? 'on' : ''}`} type="button" onClick={() => setGpsEnabled(!gpsEnabled)}>
            {gpsEnabled ? t('gpsOn') : t('gpsOff')}
          </button>
          <button className={`chip ${autoNarrate ? 'on' : ''}`} type="button" onClick={() => setAutoNarrate(!autoNarrate)}>
            {autoNarrate ? t('autoOn') : t('autoOff')}
          </button>
          <button className="chip" type="button" onClick={() => setSimOpen((v) => !v)}>
            {t('simulate')}
          </button>
          <Link className="chip" to="/admin/login">
            {t('admin')}
          </Link>
        </div>
      </header>

      <div className="stage">
        {view === 'map' ? <PoiMap /> : <PoiList />}
        {simOpen && <SimPanel onClose={() => setSimOpen(false)} />}
        <PoiSheet />
      </div>
      <AudioPlayerBar />
      {toast && (
        <div className="toast" role="status">
          {toast.text}
        </div>
      )}
    </div>
  )
}
