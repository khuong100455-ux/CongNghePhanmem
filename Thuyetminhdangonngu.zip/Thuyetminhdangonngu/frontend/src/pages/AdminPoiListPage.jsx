import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { SUPPORTED_LANGS } from '../data/seedPois'
import { useT } from '../hooks/useT'
import { api } from '../services/mockApi'
import { useAppStore } from '../store/useAppStore'

export default function AdminPoiListPage() {
  const t = useT()
  const pois = useAppStore((s) => s.pois)
  const loadPois = useAppStore((s) => s.loadPois)

  useEffect(() => {
    loadPois()
  }, [loadPois])

  async function onDelete(id) {
    if (!confirm(t('confirmDelete'))) return
    await api.deletePoi(id)
    await loadPois()
  }

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>{t('poiList')}</h1>
        <Link className="primary" to="/admin/pois/new" style={{ width: 'auto', textDecoration: 'none' }}>
          {t('newPoi')}
        </Link>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table>
          <thead>
            <tr>
              <th>{t('titleVi')}</th>
              <th>Lat / Lng</th>
              {SUPPORTED_LANGS.map((l) => (
                <th key={l}>{l.toUpperCase()}</th>
              ))}
              <th />
            </tr>
          </thead>
          <tbody>
            {pois.map((poi) => (
              <tr key={poi.id}>
                <td>{poi.i18n?.vi?.title}</td>
                <td>
                  {poi.lat.toFixed(4)}, {poi.lng.toFixed(4)}
                </td>
                {SUPPORTED_LANGS.map((l) => (
                  <td key={l}>
                    <span className={`badge ${poi.audio?.[l] === 'ready' ? 'ok' : 'no'}`}>
                      {poi.audio?.[l] === 'ready' ? t('audioReady') : t('audioMissing')}
                    </span>
                  </td>
                ))}
                <td>
                  <Link to={`/admin/pois/${poi.id}`}>{t('edit')}</Link>
                  {' · '}
                  <button className="linkish" type="button" onClick={() => onDelete(poi.id)} style={{ display: 'inline' }}>
                    {t('delete')}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
