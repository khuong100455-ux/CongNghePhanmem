import { Link, useNavigate } from 'react-router-dom'
import { LANG_META } from '../i18n/messages'
import { SUPPORTED_LANGS } from '../data/seedPois'
import { MESSAGES } from '../i18n/messages'
import { useAppStore } from '../store/useAppStore'

export default function SplashPage() {
  const navigate = useNavigate()
  const lang = useAppStore((s) => s.lang)
  const setLang = useAppStore((s) => s.setLang)
  const preview = lang || 'vi'
  const t = (key) => MESSAGES[preview][key]

  return (
    <div className="splash">
      <div className="splash-card">
        <div className="kicker">{t('appTag')}</div>
        <h1>{t('appName')}</h1>
        <p className="lead">{t('splashLead')}</p>
        <div className="lang-grid">
          {SUPPORTED_LANGS.map((code) => (
            <button
              key={code}
              type="button"
              className={`lang-btn ${lang === code ? 'active' : ''}`}
              onClick={() => setLang(code)}
            >
              <span>
                <b>{LANG_META[code].label}</b>
                <span>{code.toUpperCase()}</span>
              </span>
              <span>{lang === code ? '●' : '○'}</span>
            </button>
          ))}
        </div>
        <button className="primary" type="button" disabled={!lang} onClick={() => navigate('/explore')}>
          {t('continue')}
        </button>
        <p className="hint">{t('skipHint')}</p>
        <Link className="admin-link" to="/admin/login">
          {t('admin')}
        </Link>
      </div>
    </div>
  )
}
