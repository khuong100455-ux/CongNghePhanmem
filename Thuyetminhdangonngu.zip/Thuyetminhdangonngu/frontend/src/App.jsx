import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import AdminLayout from './pages/AdminLayout'
import AdminLoginPage from './pages/AdminLoginPage'
import AdminPoiFormPage from './pages/AdminPoiFormPage'
import AdminPoiListPage from './pages/AdminPoiListPage'
import ExplorePage from './pages/ExplorePage'
import SplashPage from './pages/SplashPage'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SplashPage />} />
        <Route path="/explore" element={<ExplorePage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminPoiListPage />} />
          <Route path="pois/:id" element={<AdminPoiFormPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
