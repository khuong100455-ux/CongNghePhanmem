import { create } from 'zustand'
import { api } from '../services/mockApi'

export const useAppStore = create((set, get) => ({
  lang: localStorage.getItem('tm_lang') || '',
  pois: [],
  loading: false,
  selectedId: null,
  gpsEnabled: false,
  autoNarrate: true,
  userPosition: null,
  simulated: false,
  online: typeof navigator === 'undefined' ? true : navigator.onLine,
  toast: null,
  view: 'map',
  player: { poiId: null, status: 'idle', tier: null },

  setLang: (lang) => {
    localStorage.setItem('tm_lang', lang)
    set({ lang })
  },

  setView: (view) => set({ view }),
  selectPoi: (id) => set({ selectedId: id }),
  setPlayer: (player) => set({ player }),
  setOnline: (online) => set({ online }),

  toastMsg: (text) => {
    set({ toast: { text, id: Date.now() } })
    setTimeout(() => {
      const cur = get().toast
      if (cur && Date.now() - cur.id > 2500) set({ toast: null })
    }, 3200)
  },
  clearToast: () => set({ toast: null }),

  loadPois: async () => {
    set({ loading: true })
    try {
      const pois = await api.loadAll(get().lang)
      set({ pois, loading: false })
    } catch {
      set({ loading: false })
      get().toastMsg('Không tải được danh sách điểm.')
    }
  },

  setGpsEnabled: (gpsEnabled) => {
    if (!gpsEnabled) set({ gpsEnabled, userPosition: get().simulated ? get().userPosition : null })
    else set({ gpsEnabled })
  },

  setAutoNarrate: (autoNarrate) => set({ autoNarrate }),

  setPosition: (userPosition) => set({ userPosition, simulated: Boolean(userPosition?.simulated) }),

  simulateAt: (poi) =>
    set({
      gpsEnabled: true,
      simulated: true,
      userPosition: { lat: poi.lat, lng: poi.lng, accuracy: 8, simulated: true },
    }),

  clearSimulation: () => set({ simulated: false, userPosition: null }),
}))
