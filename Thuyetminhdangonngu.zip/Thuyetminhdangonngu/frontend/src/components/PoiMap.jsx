import { Circle, MapContainer, Marker, TileLayer, Tooltip, useMap } from 'react-leaflet'
import { Fragment, useEffect } from 'react'
import L from 'leaflet'
import { MAP_CENTER } from '../data/seedPois'
import { resolveLocalization } from '../lib/geo'
import { useAppStore } from '../store/useAppStore'

const poiIcon = L.divIcon({ className: '', html: '<div class="marker-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] })
const userIcon = L.divIcon({ className: '', html: '<div class="marker-dot user"></div>', iconSize: [18, 18], iconAnchor: [9, 9] })

function Recenter({ position }) {
  const map = useMap()
  useEffect(() => {
    if (position) map.panTo([position.lat, position.lng])
  }, [position, map])
  return null
}

export default function PoiMap() {
  const lang = useAppStore((s) => s.lang)
  const pois = useAppStore((s) => s.pois)
  const selectPoi = useAppStore((s) => s.selectPoi)
  const selectedId = useAppStore((s) => s.selectedId)
  const userPosition = useAppStore((s) => s.userPosition)

  return (
    <MapContainer center={MAP_CENTER} zoom={15} scrollWheelZoom style={{ height: '100%', width: '100%' }}>
      <TileLayer
        attribution='&copy; OpenStreetMap'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Recenter position={userPosition} />
      {pois.map((poi) => {
        const loc = resolveLocalization(poi, lang)
        return (
          <Fragment key={poi.id}>
            <Marker
              position={[poi.lat, poi.lng]}
              icon={poiIcon}
              eventHandlers={{ click: () => selectPoi(poi.id) }}
            >
              <Tooltip>{loc.title}</Tooltip>
            </Marker>
            {selectedId === poi.id && (
              <Circle
                center={[poi.lat, poi.lng]}
                radius={poi.radius}
                pathOptions={{ color: '#b8893a', fillColor: '#b8893a', fillOpacity: 0.12, weight: 1 }}
              />
            )}
          </Fragment>
        )
      })}
      {userPosition && (
        <Marker position={[userPosition.lat, userPosition.lng]} icon={userIcon} />
      )}
    </MapContainer>
  )
}
