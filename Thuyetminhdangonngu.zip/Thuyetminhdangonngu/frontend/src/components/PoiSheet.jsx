import { useT } from '../hooks/useT'
import { resolveLocalization } from '../lib/geo'
import { playNarration } from '../services/narrationEngine'
import { useAppStore } from '../store/useAppStore'

export default function PoiSheet() {
  const t = useT()
  const lang = useAppStore((s) => s.lang)
  const pois = useAppStore((s) => s.pois)
  const selectedId = useAppStore((s) => s.selectedId)
  const selectPoi = useAppStore((s) => s.selectPoi)
  const player = useAppStore((s) => s.player)
  const poi = pois.find((p) => p.id === selectedId)
  if (!poi) return null
  const loc = resolveLocalization(poi, lang)

  return (
    <aside className="sheet">
      {loc.isFallback && <div className="warn">{t('fallbackContent')} ({loc.lang.toUpperCase()})</div>}
      <h2>{loc.title}</h2>
      <p className="muted">{loc.description}</p>
      <p className="tier">
        {t('radius')} {poi.radius}
        {t('meters')} · {loc.audioStatus === 'ready' ? t('audioReady') : t('audioMissing')}
      </p>
      <div className="row">
        <button
          className="primary"
          type="button"
          style={{ width: 'auto' }}
          disabled={player.status === 'preparing'}
          onClick={() => playNarration(poi, lang)}
        >
          {player.poiId === poi.id && player.status !== 'idle' ? t('playing') : t('play')}
        </button>
        <button className="ghost" type="button" onClick={() => selectPoi(null)}>
          {t('cancel')}
        </button>
      </div>
    </aside>
  )
}
