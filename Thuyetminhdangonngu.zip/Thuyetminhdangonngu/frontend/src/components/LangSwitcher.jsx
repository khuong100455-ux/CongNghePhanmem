import { LANG_META } from '../i18n/messages'
import { SUPPORTED_LANGS } from '../data/seedPois'
import { useAppStore } from '../store/useAppStore'
import { stopNarration } from '../services/narrationEngine'

export default function LangSwitcher({ compact = false }) {
  const lang = useAppStore((s) => s.lang)
  const setLang = useAppStore((s) => s.setLang)

  return (
    <div className="seg" role="group" aria-label="Language">
      {SUPPORTED_LANGS.map((code) => (
        <button
          key={code}
          className={lang === code ? 'on' : ''}
          type="button"
          onClick={() => {
            if (code === lang) return
            stopNarration()
            setLang(code)
          }}
        >
          {compact ? LANG_META[code].short : LANG_META[code].label}
        </button>
      ))}
    </div>
  )
}
