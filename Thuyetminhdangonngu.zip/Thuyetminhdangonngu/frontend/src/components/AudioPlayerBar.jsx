import { useT } from '../hooks/useT'
import { resolveLocalization } from '../lib/geo'
import { pauseNarration, resumeNarration, stopNarration } from '../services/narrationEngine'
import { useAppStore } from '../store/useAppStore'

const TIER_KEY = { file: 'tierFile', demand: 'tierDemand', local: 'tierLocal' }

export default function AudioPlayerBar() {
  const t = useT()
  const lang = useAppStore((s) => s.lang)
  const pois = useAppStore((s) => s.pois)
  const player = useAppStore((s) => s.player)
  const poi = pois.find((p) => p.id === player.poiId)
  const loc = poi ? resolveLocalization(poi, lang) : null
  const busy = player.status === 'preparing' || player.status === 'playing' || player.status === 'paused'
  if (!busy) {
    return (
      <div className="player">
        <div>
          <strong>{t('appName')}</strong>
          <small>{t('skipHint')}</small>
        </div>
      </div>
    )
  }

  return (
    <div className="player">
      <div>
        <strong>{player.status === 'preparing' ? t('preparing') : t('playing')}</strong>
        <small>
          {loc?.title}
          {player.tier ? ` · ${t(TIER_KEY[player.tier])}` : ''}
        </small>
      </div>
      <div className="player-btns">
        {player.status === 'playing' && (
          <button type="button" onClick={pauseNarration}>
            {t('pause')}
          </button>
        )}
        {player.status === 'paused' && (
          <button type="button" onClick={resumeNarration}>
            {t('resume')}
          </button>
        )}
        <button type="button" onClick={stopNarration}>
          {t('stop')}
        </button>
      </div>
    </div>
  )
}
