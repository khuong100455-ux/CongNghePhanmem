import { useT } from '../hooks/useT'
import { resolveLocalization } from '../lib/geo'
import { useAppStore } from '../store/useAppStore'

export default function PoiList() {
  const t = useT()
  const lang = useAppStore((s) => s.lang)
  const pois = useAppStore((s) => s.pois)
  const selectPoi = useAppStore((s) => s.selectPoi)
  const setView = useAppStore((s) => s.setView)
  if (!pois.length) return <p className="muted">{t('empty')}</p>

  return (
    <div className="poi-list">
      {pois.map((poi) => {
        const loc = resolveLocalization(poi, lang)
        return (
          <button
            key={poi.id}
            className="poi-card"
            type="button"
            onClick={() => {
              selectPoi(poi.id)
              setView('map')
            }}
          >
            {loc.isFallback && <div className="warn">{t('fallbackContent')}</div>}
            <h3>{loc.title}</h3>
            <p>{loc.description}</p>
          </button>
        )
      })}
    </div>
  )
}
