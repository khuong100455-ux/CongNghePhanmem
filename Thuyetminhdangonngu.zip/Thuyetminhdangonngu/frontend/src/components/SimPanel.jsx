import { useT } from '../hooks/useT'
import { resolveLocalization } from '../lib/geo'
import { useAppStore } from '../store/useAppStore'

export default function SimPanel({ onClose }) {
  const t = useT()
  const lang = useAppStore((s) => s.lang)
  const pois = useAppStore((s) => s.pois)
  const simulateAt = useAppStore((s) => s.simulateAt)
  const clearSimulation = useAppStore((s) => s.clearSimulation)
  const simulated = useAppStore((s) => s.simulated)

  return (
    <aside className="sim-panel">
      <h3>{t('simulate')}</h3>
      <p className="muted">{t('simulateHint')}</p>
      <div className="row">
        {pois.map((poi) => (
          <button key={poi.id} className="ghost" type="button" onClick={() => simulateAt(poi)}>
            {t('jumpHere')}: {resolveLocalization(poi, lang).title}
          </button>
        ))}
      </div>
      <div className="row">
        {simulated && (
          <button className="ghost" type="button" onClick={clearSimulation}>
            {t('clearSim')}
          </button>
        )}
        <button className="primary" type="button" style={{ width: 'auto' }} onClick={onClose}>
          {t('cancel')}
        </button>
      </div>
    </aside>
  )
}
