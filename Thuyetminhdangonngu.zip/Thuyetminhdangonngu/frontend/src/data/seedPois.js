/** Điểm thuyết minh mẫu — khu trung tâm TP.HCM. Backend sau này thay seed này bằng GET /poi/load-all. */
export const SEED_POIS = [
  {
    id: 'poi-duc-ba',
    lat: 10.7798,
    lng: 106.699,
    radius: 40,
    audio: { vi: 'ready', en: 'ready', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Nhà thờ Đức Bà Sài Gòn',
        description:
          'Nhà thờ chính tòa Đức Bà được xây từ năm 1863 đến 1880, là công trình Gothic đặc trưng của trung tâm Sài Gòn. Hai tháp chuông cao 58 mét từng là điểm định hướng cho người đi bộ quanh công trường Công xã Paris. Đá ngoài trời lấy từ Marseille, gạch đỏ trong nhà vẫn giữ màu gần như nguyên bản.',
      },
      en: {
        title: 'Saigon Notre-Dame Cathedral',
        description:
          'Built between 1863 and 1880, the cathedral is a Gothic landmark of central Saigon. Its 58-metre bell towers once helped pedestrians orient themselves around Paris Commune Square. The façade stone came from Marseille, while the interior red bricks have kept nearly their original colour.',
      },
      ja: {
        title: 'サイゴン大教会',
        description:
          '1863年から1880年にかけて建てられたゴシック様式の大教会です。高さ58メートルの鐘楼は、かつてのパリ・コミューン広場周辺で目印となっていました。外壁の石はマルセイユ産で、内部の赤れんがはほぼ当時の色を保っています。',
      },
    },
  },
  {
    id: 'poi-buu-dien',
    lat: 10.7799,
    lng: 106.6998,
    radius: 35,
    audio: { vi: 'ready', en: 'missing', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Bưu điện Trung tâm Sài Gòn',
        description:
          'Bưu điện do kiến trúc sư Gustave Eiffel thiết kế khung, hoàn thành năm 1891. Bên trong còn bản đồ đường dây điện tín Đông Dương và bản đồ Sài Gòn–Gia Định. Quầy gỗ, đồng hồ lớn và mái vòm sắt là phần thuyết minh khách thường dừng lâu nhất.',
      },
      en: {
        title: 'Saigon Central Post Office',
        description:
          'Completed in 1891 with a steel frame associated with Gustave Eiffel’s workshop, the post office still shows an Indochina telegraph map and a Saigon–Gia Dinh map. Wooden counters, the large clock and the iron vault are the usual highlights of a guided stop.',
      },
      ja: {
        title: 'サイゴン中央郵便局',
        description:
          '1891年完成。鉄骨はギュスターヴ・エッフェルの工房と関連づけられます。館内にはインドシナ電信網の地図とサイゴン＝ジャディン地図が残っています。木製カウンター、大時計、鉄のアーチが案内の見どころです。',
      },
    },
  },
  {
    id: 'poi-pho-sach',
    lat: 10.7806,
    lng: 106.6993,
    radius: 30,
    audio: { vi: 'ready', en: 'ready', ja: 'ready' },
    i18n: {
      vi: {
        title: 'Đường sách Nguyễn Văn Bình',
        description:
          'Con đường sách nằm sát nhà thờ và bưu điện, tập trung nhà xuất bản, quán đọc và sự kiện cuối tuần. Đây là điểm nối bộ giữa di sản kiến trúc và đời sống chữ nghĩa đương đại — phù hợp để thuyết minh về văn hóa đọc Sài Gòn.',
      },
      en: {
        title: 'Nguyen Van Binh Book Street',
        description:
          'This pedestrian book street sits beside the cathedral and post office, with publishers, reading cafés and weekend events. It links architectural heritage with contemporary reading culture — a natural stop on a walking commentary.',
      },
      ja: {
        title: 'グエン・ヴァン・ビン書籍通り',
        description:
          '大教会と郵便局のそばにある歩行者専用の本の通りです。出版社、読書カフェ、週末のイベントが集まり、建築遺産と現代の読書文化をつなぐ解説ポイントになります。',
      },
    },
  },
  {
    id: 'poi-nha-hat',
    lat: 10.7766,
    lng: 106.7031,
    radius: 35,
    audio: { vi: 'ready', en: 'ready', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Nhà hát Thành phố',
        description:
          'Nhà hát được khánh thành năm 1900, mặt tiền theo phong cách Flamboyant với phù điêu và đèn chùm. Công trình từng là nghị trường rồi trả lại chức năng biểu diễn. Quảng trường phía trước là nơi GPS dễ kích hoạt thuyết minh khi khách đi bộ từ phố Đồng Khởi.',
      },
      en: {
        title: 'Saigon Opera House',
        description:
          'Opened in 1900, the theatre has a Flamboyant façade, reliefs and chandeliers. It served as an assembly hall before returning to performance use. The square in front is an easy geofence trigger for walkers coming from Dong Khoi Street.',
      },
      ja: {
        title: 'サイゴン歌劇場',
        description:
          '1900年開館。華やかなファサード、レリーフ、シャンデリアが特徴です。議事堂として使われた時期を経て、再び劇場になりました。ドンコイ通りから歩くと、前の広場で位置情報による解説が始まりやすい地点です。',
      },
    },
  },
  {
    id: 'poi-dinh-doc-lap',
    lat: 10.777,
    lng: 106.6955,
    radius: 50,
    audio: { vi: 'ready', en: 'missing', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Dinh Độc Lập',
        description:
          'Dinh Độc Lập do kiến trúc sư Ngô Viết Thụ thiết kế, hoàn thành năm 1966. Mặt bằng chữ T theo thuật phong thủy, phòng họp, tầng hầm chỉ huy và nóc dinh gắn với sự kiện 30/4/1975. Bán kính thuyết minh rộng hơn vì khuôn viên lớn.',
      },
      en: {
        title: 'Independence Palace',
        description:
          'Designed by architect Ngo Viet Thu and finished in 1966, the palace follows a T-shaped plan. Conference rooms, the command bunker and the rooftop are tied to 30 April 1975. The commentary radius is wider because the grounds are large.',
      },
      ja: {
        title: '独立宮殿',
        description:
          '建築家ゴー・ヴィエット・トゥの設計で1966年に完成しました。風水に基づくT字の平面、会議室、地下指揮室、屋上は1975年4月30日の出来事と結びつきます。敷地が広いため、解説の半径も広めです。',
      },
    },
  },
  {
    id: 'poi-ben-thanh',
    lat: 10.772,
    lng: 106.6983,
    radius: 45,
    audio: { vi: 'ready', en: 'ready', ja: 'ready' },
    i18n: {
      vi: {
        title: 'Chợ Bến Thành',
        description:
          'Chợ Bến Thành khai trương năm 1914, mặt đồng hồ hướng ra vòng xoay là hình ảnh nhận diện Sài Gòn. Bên trong chia ngành hàng thực phẩm, lưu niệm, vải. Thuyết minh nên nói ngắn vì tiếng ồn cao — ưu tiên bản audio đã ghi sẵn hơn TTS sống.',
      },
      en: {
        title: 'Ben Thanh Market',
        description:
          'Opened in 1914, the clock-facing façade is an icon of Saigon. Inside, stalls split among food, souvenirs and textiles. Keep the commentary short because of noise — pre-generated audio works better than live TTS here.',
      },
      ja: {
        title: 'ベンタイン市場',
        description:
          '1914年開業。時計のある正面はサイゴンの象徴です。内部は食品、土産、布地などに分かれています。騒音が大きいため解説は短く、リアルタイムTTSより事前音声が向きます。',
      },
    },
  },
  {
    id: 'poi-bao-tang-my-thuat',
    lat: 10.7694,
    lng: 106.699,
    radius: 30,
    audio: { vi: 'missing', en: 'missing', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Bảo tàng Mỹ thuật TP.HCM',
        description:
          'Bảo tàng đặt trong dinh thự Pháp đầu thế kỷ 20 của gia đình Hui Bon Hoa. Ba khối nhà trưng bày mỹ thuật Việt Nam hiện đại và cổ vật. Điểm này cố ý chưa có file audio sẵn — dùng để thử tầng on-demand và TTS trình duyệt.',
      },
      en: {
        title: 'HCMC Fine Arts Museum',
        description:
          'The museum occupies an early-20th-century mansion of the Hui Bon Hoa family. Three blocks show modern Vietnamese art and antiques. This stop has no pre-generated audio on purpose — use it to test on-demand generation and browser TTS.',
      },
      ja: {
        title: 'ホーチミン市美術館',
        description:
          '20世紀初頭のユイ・ボン・ホア家の邸宅を利用した美術館です。3棟で近現代のベトナム美術と古美術を展示します。この地点は意図的に音声ファイルを置いておらず、オンデマンド生成とブラウザTTSの確認用です。',
      },
    },
  },
  {
    id: 'poi-cong-vien-239',
    lat: 10.7686,
    lng: 106.6942,
    radius: 40,
    audio: { vi: 'ready', en: 'ready', ja: 'missing' },
    i18n: {
      vi: {
        title: 'Công viên 23 tháng 9',
        description:
          'Công viên trải dài cạnh ga Sài Gòn cũ, là khoảng thở giữa chợ Bến Thành và phố Tây. Thích hợp làm điểm kết lộ trình bộ: tóm tắt bốn công trình vừa đi và gợi ý khách đổi ngôn ngữ để nghe lại cùng nội dung.',
      },
      en: {
        title: '23 September Park',
        description:
          'The park runs beside the old Saigon station, a pause between Ben Thanh and the backpacker streets. It works as a closing stop: recap the four buildings just visited and invite visitors to replay the same script in another language.',
      },
      ja: {
        title: '9月23日公園',
        description:
          '旧サイゴン駅のそばに広がる公園で、ベンタイン市場とバックパッカー街のあいだの休憩地点です。コースの締めくくりとして、歩いてきた建物を振り返り、別の言語で同じ解説を聞き直す案内に向きます。',
      },
    },
  },
]

export const MAP_CENTER = [10.7765, 106.699]
export const SUPPORTED_LANGS = ['vi', 'en', 'ja']
export const ADMIN_DEMO = { username: 'admin', password: 'thuyetminh' }
