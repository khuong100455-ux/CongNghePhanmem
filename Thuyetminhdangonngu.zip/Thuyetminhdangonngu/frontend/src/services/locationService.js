const THROTTLE_MS = 5000
const TIMEOUT_MS = 15000

export function startWatch({ onUpdate, onError }) {
  if (!navigator.geolocation) {
    onError?.(new Error('Geolocation unsupported'))
    return () => {}
  }

  let lastEmit = 0
  const id = navigator.geolocation.watchPosition(
    (pos) => {
      const now = Date.now()
      if (now - lastEmit < THROTTLE_MS) return
      lastEmit = now
      onUpdate({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
        simulated: false,
      })
    },
    (err) => onError?.(err),
    { enableHighAccuracy: true, timeout: TIMEOUT_MS, maximumAge: 30000 },
  )

  return () => navigator.geolocation.clearWatch(id)
}
