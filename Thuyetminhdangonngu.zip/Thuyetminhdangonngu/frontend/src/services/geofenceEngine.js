import { haversineMeters } from '../lib/geo'

/** Demo: cooldown 45s (bản production trong file mẫu là 5 phút). */
export const GEOFENCE = {
  debounceMs: 3000,
  cooldownMs: 45_000,
  reconcileMs: 5000,
}

export function createGeofenceEngine({ onEnter, getEnabled }) {
  const pending = new Map()
  const lastPlayed = new Map()
  let inside = new Set()

  function check(position, pois) {
    if (!getEnabled() || !position) return
    const now = Date.now()
    const currentlyInside = new Set()

    for (const poi of pois) {
      const d = haversineMeters(position, { lat: poi.lat, lng: poi.lng })
      const radius = poi.radius ?? 30
      if (d <= radius) currentlyInside.add(poi.id)
    }

    for (const id of currentlyInside) {
      if (inside.has(id)) {
        pending.delete(id)
        continue
      }
      if (!pending.has(id)) pending.set(id, now)
      else if (now - pending.get(id) >= GEOFENCE.debounceMs) {
        const last = lastPlayed.get(id) ?? 0
        if (now - last >= GEOFENCE.cooldownMs) {
          lastPlayed.set(id, now)
          const poi = pois.find((p) => p.id === id)
          if (poi) onEnter(poi)
        }
        pending.delete(id)
      }
    }

    for (const id of [...pending.keys()]) {
      if (!currentlyInside.has(id)) pending.delete(id)
    }

    inside = currentlyInside
  }

  return { check }
}
