import { LANG_META } from '../i18n/messages'
import { resolveLocalization } from '../lib/geo'

let playGen = 0
let objectUrl = null

let active = {
  poiId: null,
  audio: null,
  utterance: null,
  status: 'idle',
  tier: null,
}

const listeners = new Set()

function emit(partial) {
  active = { ...active, ...partial }
  listeners.forEach((fn) => fn(getState()))
}

export function getState() {
  return {
    poiId: active.poiId,
    status: active.status,
    tier: active.tier,
  }
}

export function subscribe(fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

function revokeUrl() {
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl)
    objectUrl = null
  }
}

export function stopNarration() {
  playGen += 1
  if (active.audio) {
    active.audio.pause()
    active.audio.src = ''
  }
  if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel()
  active.audio = null
  active.utterance = null
  revokeUrl()
  emit({ poiId: null, status: 'idle', tier: null })
}

function waitVoices() {
  const now = speechSynthesis.getVoices()
  if (now.length) return Promise.resolve(now)
  return new Promise((resolve) => {
    const done = () => resolve(speechSynthesis.getVoices())
    speechSynthesis.addEventListener('voiceschanged', done, { once: true })
    setTimeout(done, 600)
  })
}

function pickVoice(lang, voices) {
  const locale = (LANG_META[lang]?.speech || 'vi-VN').toLowerCase()
  const patterns = {
    vi: [/hoai/i, /nam minh/i, /vietnamese/i, /\bvi[-_]/i],
    en: [/jenny/i, /aria/i, /natural/i, /google us english/i, /en-US/i],
    ja: [/nanami/i, /keita/i, /google 日本語/i, /^ja/i],
  }
  for (const re of patterns[lang] || []) {
    const hit = voices.find((v) => re.test(v.name) || re.test(v.lang))
    if (hit) return hit
  }
  return (
    voices.find((v) => v.lang.toLowerCase() === locale) ||
    voices.find((v) => v.lang.toLowerCase().startsWith(lang)) ||
    null
  )
}

function splitChunks(text) {
  const parts = text
    .split(/(?<=[.!?。！？…])\s+/)
    .map((s) => s.trim())
    .filter(Boolean)
  return parts.length ? parts : [text]
}

function playSpeech(text, lang) {
  return new Promise((resolve, reject) => {
    if (typeof speechSynthesis === 'undefined') {
      reject(new Error('No speechSynthesis'))
      return
    }
    waitVoices()
      .then((voices) => {
        speechSynthesis.cancel()
        const voice = pickVoice(lang, voices)
        const chunks = splitChunks(text)
        const locale = LANG_META[lang]?.speech ?? 'vi-VN'
        const rate = lang === 'vi' ? 0.88 : lang === 'en' ? 0.9 : 0.92

        const speakAt = (i) => {
          if (i >= chunks.length) {
            resolve()
            return
          }
          const u = new SpeechSynthesisUtterance(chunks[i])
          u.lang = voice?.lang || locale
          if (voice) u.voice = voice
          u.rate = rate
          u.pitch = 1
          active.utterance = u
          u.onend = () => speakAt(i + 1)
          u.onerror = (e) => reject(e.error || new Error('TTS error'))
          speechSynthesis.speak(u)
        }
        speakAt(0)
      })
      .catch(reject)
  })
}

async function playFile(url) {
  const audio = new Audio(url)
  audio.preload = 'auto'
  active.audio = audio
  await audio.play()
  await new Promise((resolve, reject) => {
    audio.onended = resolve
    audio.onerror = () => reject(new Error('audio error'))
  })
}

async function fetchNeuralAudio(text, lang) {
  const res = await fetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, lang }),
  })
  if (!res.ok) throw new Error(`neural ${res.status}`)
  const blob = await res.blob()
  if (!blob.size) throw new Error('empty audio')
  revokeUrl()
  objectUrl = URL.createObjectURL(blob)
  return objectUrl
}

/**
 * Neural Microsoft (HoaiMy / Jenny / Nanami) qua /api/tts.
 * Fallback: speechSynthesis đã chọn giọng đúng ngôn ngữ, nói chậm hơn.
 */
export async function playNarration(poi, lang) {
  stopNarration()
  const myGen = playGen
  const loc = resolveLocalization(poi, lang)
  const script = `${loc.title}. ${loc.description}`
  emit({ poiId: poi.id, status: 'preparing', tier: 'demand' })

  const stillMine = () => myGen === playGen

  try {
    const url = loc.audioUrl || (await fetchNeuralAudio(script, loc.lang))
    if (!stillMine()) return 'stopped'
    emit({ status: 'playing', tier: loc.audioUrl ? 'file' : 'demand' })
    await playFile(url)
    if (stillMine()) emit({ poiId: null, status: 'idle', tier: null })
    return loc.audioUrl ? 'file' : 'demand'
  } catch {
    if (!stillMine()) return 'stopped'
    emit({ status: 'playing', tier: 'local' })
    try {
      await playSpeech(script, loc.lang)
      if (stillMine()) emit({ poiId: null, status: 'idle', tier: null })
      return 'local'
    } catch {
      if (stillMine()) emit({ poiId: null, status: 'idle', tier: null })
      throw new Error('Không phát được thuyết minh')
    }
  }
}

export function pauseNarration() {
  if (active.audio && !active.audio.paused) {
    active.audio.pause()
    emit({ status: 'paused' })
    return
  }
  if (typeof speechSynthesis !== 'undefined' && speechSynthesis.speaking) {
    speechSynthesis.pause()
    emit({ status: 'paused' })
  }
}

export function resumeNarration() {
  if (active.audio && active.audio.paused) {
    active.audio.play()
    emit({ status: 'playing' })
    return
  }
  if (typeof speechSynthesis !== 'undefined' && speechSynthesis.paused) {
    speechSynthesis.resume()
    emit({ status: 'playing' })
  }
}
