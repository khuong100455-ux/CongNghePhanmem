import { ADMIN_DEMO, SEED_POIS } from '../data/seedPois'

const STORAGE_KEY = 'tm_pois_v1'
const SESSION_KEY = 'tm_admin_session'

function delay(ms = 350) {
  return new Promise((r) => setTimeout(r, ms))
}

function loadPois() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch {
    /* ignore */
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_POIS))
  return structuredClone(SEED_POIS)
}

function savePois(pois) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(pois))
}

export const api = {
  async loadAll(lang) {
    await delay(280)
    void lang
    return loadPois()
  },

  async getPoi(id) {
    await delay(120)
    return loadPois().find((p) => p.id === id) ?? null
  },

  async savePoi(poi) {
    await delay(320)
    const list = loadPois()
    const idx = list.findIndex((p) => p.id === poi.id)
    if (idx >= 0) list[idx] = poi
    else list.push(poi)
    savePois(list)
    return poi
  },

  async deletePoi(id) {
    await delay(200)
    savePois(loadPois().filter((p) => p.id !== id))
  },

  /**
   * Khi có backend: POST /localizations/on-demand rồi trả audio_url.
   * Frontend-only: chờ giả lập, không có file MP3 thật → engine xuống TTS trình duyệt.
   */
  async requestOnDemandAudio(poiId, lang) {
    await delay(1100)
    const poi = loadPois().find((p) => p.id === poiId)
    if (!poi) throw new Error('POI not found')
    if (poi.audio?.[lang] === 'ready') {
      return { audioUrl: null, ready: true, simulated: true }
    }
    return { audioUrl: null, ready: false, simulated: true }
  },

  async generateAudio(poiId, lang) {
    await delay(1400)
    const list = loadPois()
    const poi = list.find((p) => p.id === poiId)
    if (!poi) throw new Error('POI not found')
    poi.audio = { ...poi.audio, [lang]: 'ready' }
    savePois(list)
    return poi
  },

  async login(username, password) {
    await delay(250)
    if (username === ADMIN_DEMO.username && password === ADMIN_DEMO.password) {
      sessionStorage.setItem(SESSION_KEY, 'ok')
      return { ok: true }
    }
    return { ok: false }
  },

  logout() {
    sessionStorage.removeItem(SESSION_KEY)
  },

  isAuthed() {
    return sessionStorage.getItem(SESSION_KEY) === 'ok'
  },
}
