import { MESSAGES } from '../i18n/messages'
import { useAppStore } from '../store/useAppStore'

export function useT() {
  const lang = useAppStore((s) => s.lang) || 'vi'
  const dict = MESSAGES[lang] || MESSAGES.vi
  return (key) => dict[key] ?? MESSAGES.vi[key] ?? key
}
