import { createHash } from 'node:crypto'
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts'

const VOICES = {
  vi: 'vi-VN-HoaiMyNeural',
  en: 'en-US-JennyNeural',
  ja: 'ja-JP-NanamiNeural',
}

const cache = new Map()

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', (c) => chunks.push(c))
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

function streamToBuffer(stream) {
  return new Promise((resolve, reject) => {
    const chunks = []
    stream.on('data', (d) => chunks.push(d))
    stream.on('end', () => resolve(Buffer.concat(chunks)))
    stream.on('close', () => resolve(Buffer.concat(chunks)))
    stream.on('error', reject)
  })
}

async function synthesize(text, lang) {
  const voice = VOICES[lang] || VOICES.vi
  const key = createHash('sha1').update(`${voice}\n${text}`).digest('hex')
  const hit = cache.get(key)
  if (hit) return hit

  const tts = new MsEdgeTTS()
  const format =
    OUTPUT_FORMAT.AUDIO_24KHZ_96KBITRATE_MONO_MP3 ??
    OUTPUT_FORMAT.WEBM_24KHZ_16BIT_MONO_OPUS
  await tts.setMetadata(voice, format)
  const result = tts.toStream(text, { rate: lang === 'en' ? 0.92 : 0.88 })
  const audioStream = result?.audioStream ?? result
  const buf = await streamToBuffer(audioStream)
  if (!buf?.length) throw new Error('Empty TTS audio')
  cache.set(key, buf)
  return buf
}

async function handleTts(req, res) {
  if (req.method === 'OPTIONS') {
    res.statusCode = 204
    res.end()
    return
  }
  if (req.method !== 'POST') {
    res.statusCode = 405
    res.end('POST only')
    return
  }
  try {
    const body = JSON.parse((await readBody(req)) || '{}')
    const text = String(body.text || '').trim()
    const lang = body.lang === 'en' || body.lang === 'ja' ? body.lang : 'vi'
    if (!text) {
      res.statusCode = 400
      res.end('Missing text')
      return
    }
    const buf = await synthesize(text.slice(0, 1800), lang)
    const isMp3 = buf[0] === 0xff || buf[0] === 0x49
    res.setHeader('Content-Type', isMp3 ? 'audio/mpeg' : 'audio/webm')
    res.setHeader('Cache-Control', 'private, max-age=86400')
    res.end(buf)
  } catch (err) {
    console.error('[tts]', err)
    res.statusCode = 502
    res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ error: err?.message || 'TTS failed' }))
  }
}

export function ttsPlugin() {
  return {
    name: 'neural-tts',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const path = req.url?.split('?')[0]
        if (path !== '/api/tts') return next()
        void handleTts(req, res)
      })
    },
  }
}
